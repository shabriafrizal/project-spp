﻿
namespace Desktop
{
    partial class FormSiswa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSiswa));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_detail = new System.Windows.Forms.Panel();
            this.lb_telp = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lb_nominal = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pb_foto_detail = new System.Windows.Forms.PictureBox();
            this.lb_lahir = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lb_kelamin = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lb_nis = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lb_spp = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lb_status = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lb_kelas = new System.Windows.Forms.Label();
            this.lb_created = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_nisn = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.lb_alamat = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.rb_perempuan = new System.Windows.Forms.RadioButton();
            this.rb_laki = new System.Windows.Forms.RadioButton();
            this.pb_foto = new System.Windows.Forms.PictureBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.dtpick_lahir = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tbox_nis = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tbox_telp = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.cbox_spp = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tbox_nama = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cbox_kelas = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tbox_alamat = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbox_nisn = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel_not_found = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.check_showall = new System.Windows.Forms.CheckBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dgv_siswa = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbox_search = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_detail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel_not_found.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_siswa)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_detail
            // 
            this.panel_detail.BackColor = System.Drawing.Color.White;
            this.panel_detail.Controls.Add(this.lb_telp);
            this.panel_detail.Controls.Add(this.label26);
            this.panel_detail.Controls.Add(this.lb_nominal);
            this.panel_detail.Controls.Add(this.label24);
            this.panel_detail.Controls.Add(this.pb_foto_detail);
            this.panel_detail.Controls.Add(this.lb_lahir);
            this.panel_detail.Controls.Add(this.label23);
            this.panel_detail.Controls.Add(this.lb_kelamin);
            this.panel_detail.Controls.Add(this.label21);
            this.panel_detail.Controls.Add(this.lb_nis);
            this.panel_detail.Controls.Add(this.label17);
            this.panel_detail.Controls.Add(this.label18);
            this.panel_detail.Controls.Add(this.lb_spp);
            this.panel_detail.Controls.Add(this.label16);
            this.panel_detail.Controls.Add(this.lb_status);
            this.panel_detail.Controls.Add(this.label13);
            this.panel_detail.Controls.Add(this.lb_kelas);
            this.panel_detail.Controls.Add(this.lb_created);
            this.panel_detail.Controls.Add(this.lb_nama);
            this.panel_detail.Controls.Add(this.lb_nisn);
            this.panel_detail.Controls.Add(this.label7);
            this.panel_detail.Controls.Add(this.label8);
            this.panel_detail.Controls.Add(this.label9);
            this.panel_detail.Controls.Add(this.label10);
            this.panel_detail.Controls.Add(this.button8);
            this.panel_detail.Controls.Add(this.label11);
            this.panel_detail.Controls.Add(this.lb_alamat);
            this.panel_detail.Location = new System.Drawing.Point(727, 19);
            this.panel_detail.Margin = new System.Windows.Forms.Padding(2);
            this.panel_detail.Name = "panel_detail";
            this.panel_detail.Size = new System.Drawing.Size(712, 787);
            this.panel_detail.TabIndex = 45;
            // 
            // lb_telp
            // 
            this.lb_telp.AutoSize = true;
            this.lb_telp.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_telp.ForeColor = System.Drawing.Color.Black;
            this.lb_telp.Location = new System.Drawing.Point(379, 513);
            this.lb_telp.Name = "lb_telp";
            this.lb_telp.Size = new System.Drawing.Size(52, 25);
            this.lb_telp.TabIndex = 60;
            this.lb_telp.Text = "Text";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(375, 489);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 17);
            this.label26.TabIndex = 59;
            this.label26.Text = "Phone";
            // 
            // lb_nominal
            // 
            this.lb_nominal.AutoSize = true;
            this.lb_nominal.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal.ForeColor = System.Drawing.Color.Black;
            this.lb_nominal.Location = new System.Drawing.Point(40, 443);
            this.lb_nominal.Name = "lb_nominal";
            this.lb_nominal.Size = new System.Drawing.Size(52, 25);
            this.lb_nominal.TabIndex = 58;
            this.lb_nominal.Text = "Text";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(37, 420);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(87, 17);
            this.label24.TabIndex = 57;
            this.label24.Text = "Fee nominal";
            // 
            // pb_foto_detail
            // 
            this.pb_foto_detail.BackColor = System.Drawing.Color.White;
            this.pb_foto_detail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto_detail.Location = new System.Drawing.Point(525, 41);
            this.pb_foto_detail.Name = "pb_foto_detail";
            this.pb_foto_detail.Size = new System.Drawing.Size(120, 120);
            this.pb_foto_detail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto_detail.TabIndex = 56;
            this.pb_foto_detail.TabStop = false;
            // 
            // lb_lahir
            // 
            this.lb_lahir.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_lahir.ForeColor = System.Drawing.Color.Black;
            this.lb_lahir.Location = new System.Drawing.Point(378, 377);
            this.lb_lahir.Name = "lb_lahir";
            this.lb_lahir.Size = new System.Drawing.Size(133, 25);
            this.lb_lahir.TabIndex = 55;
            this.lb_lahir.Text = "12/12/2022";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(375, 353);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 17);
            this.label23.TabIndex = 54;
            this.label23.Text = "Date of birth";
            // 
            // lb_kelamin
            // 
            this.lb_kelamin.AutoSize = true;
            this.lb_kelamin.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kelamin.ForeColor = System.Drawing.Color.Black;
            this.lb_kelamin.Location = new System.Drawing.Point(378, 306);
            this.lb_kelamin.Name = "lb_kelamin";
            this.lb_kelamin.Size = new System.Drawing.Size(52, 25);
            this.lb_kelamin.TabIndex = 53;
            this.lb_kelamin.Text = "Text";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(375, 282);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 17);
            this.label21.TabIndex = 52;
            this.label21.Text = "Gender";
            // 
            // lb_nis
            // 
            this.lb_nis.AutoSize = true;
            this.lb_nis.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nis.ForeColor = System.Drawing.Color.Black;
            this.lb_nis.Location = new System.Drawing.Point(378, 234);
            this.lb_nis.Name = "lb_nis";
            this.lb_nis.Size = new System.Drawing.Size(52, 25);
            this.lb_nis.TabIndex = 51;
            this.lb_nis.Text = "Text";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(375, 210);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(27, 17);
            this.label17.TabIndex = 50;
            this.label17.Text = "NIS";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(38, 514);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 17);
            this.label18.TabIndex = 48;
            this.label18.Text = "Address";
            // 
            // lb_spp
            // 
            this.lb_spp.AutoSize = true;
            this.lb_spp.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_spp.ForeColor = System.Drawing.Color.Black;
            this.lb_spp.Location = new System.Drawing.Point(40, 354);
            this.lb_spp.Name = "lb_spp";
            this.lb_spp.Size = new System.Drawing.Size(52, 25);
            this.lb_spp.TabIndex = 47;
            this.lb_spp.Text = "Text";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(37, 331);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 17);
            this.label16.TabIndex = 46;
            this.label16.Text = "Fee category";
            // 
            // lb_status
            // 
            this.lb_status.AutoSize = true;
            this.lb_status.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_status.ForeColor = System.Drawing.Color.Black;
            this.lb_status.Location = new System.Drawing.Point(378, 583);
            this.lb_status.Name = "lb_status";
            this.lb_status.Size = new System.Drawing.Size(52, 25);
            this.lb_status.TabIndex = 45;
            this.lb_status.Text = "Text";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(375, 559);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 17);
            this.label13.TabIndex = 44;
            this.label13.Text = "Status";
            // 
            // lb_kelas
            // 
            this.lb_kelas.AutoSize = true;
            this.lb_kelas.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kelas.ForeColor = System.Drawing.Color.Black;
            this.lb_kelas.Location = new System.Drawing.Point(379, 444);
            this.lb_kelas.Name = "lb_kelas";
            this.lb_kelas.Size = new System.Drawing.Size(52, 25);
            this.lb_kelas.TabIndex = 43;
            this.lb_kelas.Text = "Text";
            // 
            // lb_created
            // 
            this.lb_created.AutoSize = true;
            this.lb_created.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_created.ForeColor = System.Drawing.Color.Black;
            this.lb_created.Location = new System.Drawing.Point(41, 669);
            this.lb_created.Name = "lb_created";
            this.lb_created.Size = new System.Drawing.Size(52, 25);
            this.lb_created.TabIndex = 42;
            this.lb_created.Text = "Text";
            // 
            // lb_nama
            // 
            this.lb_nama.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama.ForeColor = System.Drawing.Color.Black;
            this.lb_nama.Location = new System.Drawing.Point(41, 149);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(454, 25);
            this.lb_nama.TabIndex = 41;
            this.lb_nama.Text = "Text";
            // 
            // lb_nisn
            // 
            this.lb_nisn.AutoSize = true;
            this.lb_nisn.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nisn.ForeColor = System.Drawing.Color.Black;
            this.lb_nisn.Location = new System.Drawing.Point(36, 256);
            this.lb_nisn.Name = "lb_nisn";
            this.lb_nisn.Size = new System.Drawing.Size(52, 25);
            this.lb_nisn.TabIndex = 40;
            this.lb_nisn.Text = "Text";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(375, 420);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 17);
            this.label7.TabIndex = 39;
            this.label7.Text = "Class";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(38, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(38, 645);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "Created At";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(33, 233);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 17);
            this.label10.TabIndex = 33;
            this.label10.Text = "NISN";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.BorderSize = 2;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Green;
            this.button8.Location = new System.Drawing.Point(519, 727);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(126, 37);
            this.button8.TabIndex = 31;
            this.button8.Text = "Back";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 41);
            this.label11.TabIndex = 23;
            this.label11.Text = "Student";
            // 
            // lb_alamat
            // 
            this.lb_alamat.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_alamat.ForeColor = System.Drawing.Color.Black;
            this.lb_alamat.Location = new System.Drawing.Point(41, 538);
            this.lb_alamat.Name = "lb_alamat";
            this.lb_alamat.Size = new System.Drawing.Size(262, 89);
            this.lb_alamat.TabIndex = 49;
            this.lb_alamat.Text = "Text";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.rb_perempuan);
            this.panel2.Controls.Add(this.rb_laki);
            this.panel2.Controls.Add(this.pb_foto);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(744, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(712, 787);
            this.panel2.TabIndex = 44;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.FlatAppearance.BorderSize = 2;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.Green;
            this.button12.Location = new System.Drawing.Point(526, 575);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(126, 37);
            this.button12.TabIndex = 54;
            this.button12.Text = "Clear";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Green;
            this.button11.FlatAppearance.BorderSize = 2;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(400, 574);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(120, 37);
            this.button11.TabIndex = 53;
            this.button11.Text = "Select Image";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(31, 539);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 17);
            this.label20.TabIndex = 52;
            this.label20.Text = "Gender";
            // 
            // rb_perempuan
            // 
            this.rb_perempuan.AutoSize = true;
            this.rb_perempuan.Location = new System.Drawing.Point(217, 574);
            this.rb_perempuan.Name = "rb_perempuan";
            this.rb_perempuan.Size = new System.Drawing.Size(62, 17);
            this.rb_perempuan.TabIndex = 51;
            this.rb_perempuan.TabStop = true;
            this.rb_perempuan.Text = "Woman";
            this.rb_perempuan.UseVisualStyleBackColor = true;
            // 
            // rb_laki
            // 
            this.rb_laki.AutoSize = true;
            this.rb_laki.Location = new System.Drawing.Point(85, 574);
            this.rb_laki.Name = "rb_laki";
            this.rb_laki.Size = new System.Drawing.Size(46, 17);
            this.rb_laki.TabIndex = 50;
            this.rb_laki.TabStop = true;
            this.rb_laki.Text = "Man";
            this.rb_laki.UseVisualStyleBackColor = true;
            // 
            // pb_foto
            // 
            this.pb_foto.BackColor = System.Drawing.Color.White;
            this.pb_foto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto.Location = new System.Drawing.Point(470, 436);
            this.pb_foto.Name = "pb_foto";
            this.pb_foto.Size = new System.Drawing.Size(120, 120);
            this.pb_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto.TabIndex = 48;
            this.pb_foto.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(37, 452);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 17);
            this.label19.TabIndex = 47;
            this.label19.Text = "Date of birth";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.dtpick_lahir);
            this.panel11.Location = new System.Drawing.Point(34, 471);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(304, 38);
            this.panel11.TabIndex = 46;
            // 
            // dtpick_lahir
            // 
            this.dtpick_lahir.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpick_lahir.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpick_lahir.Location = new System.Drawing.Point(4, 5);
            this.dtpick_lahir.Name = "dtpick_lahir";
            this.dtpick_lahir.Size = new System.Drawing.Size(294, 27);
            this.dtpick_lahir.TabIndex = 48;
            this.dtpick_lahir.Value = new System.DateTime(2023, 2, 24, 0, 0, 0, 0);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(37, 164);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 17);
            this.label15.TabIndex = 45;
            this.label15.Text = "NIS";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.tbox_nis);
            this.panel10.Location = new System.Drawing.Point(34, 183);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(304, 38);
            this.panel10.TabIndex = 44;
            // 
            // tbox_nis
            // 
            this.tbox_nis.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_nis.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_nis.Location = new System.Drawing.Point(12, 9);
            this.tbox_nis.Name = "tbox_nis";
            this.tbox_nis.Size = new System.Drawing.Size(272, 19);
            this.tbox_nis.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(37, 350);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 17);
            this.label14.TabIndex = 43;
            this.label14.Text = "Phone";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.tbox_telp);
            this.panel9.Location = new System.Drawing.Point(34, 369);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(304, 38);
            this.panel9.TabIndex = 42;
            // 
            // tbox_telp
            // 
            this.tbox_telp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_telp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_telp.Location = new System.Drawing.Point(12, 9);
            this.tbox_telp.Name = "tbox_telp";
            this.tbox_telp.Size = new System.Drawing.Size(272, 19);
            this.tbox_telp.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(375, 210);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 17);
            this.label12.TabIndex = 41;
            this.label12.Text = "Fee category";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.cbox_spp);
            this.panel8.Location = new System.Drawing.Point(372, 230);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(304, 38);
            this.panel8.TabIndex = 40;
            // 
            // cbox_spp
            // 
            this.cbox_spp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp.FormattingEnabled = true;
            this.cbox_spp.Location = new System.Drawing.Point(9, 4);
            this.cbox_spp.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp.Name = "cbox_spp";
            this.cbox_spp.Size = new System.Drawing.Size(285, 29);
            this.cbox_spp.TabIndex = 43;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(37, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 39;
            this.label6.Text = "Name";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.tbox_nama);
            this.panel7.Location = new System.Drawing.Point(34, 272);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(304, 38);
            this.panel7.TabIndex = 38;
            // 
            // tbox_nama
            // 
            this.tbox_nama.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_nama.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_nama.Location = new System.Drawing.Point(12, 9);
            this.tbox_nama.Name = "tbox_nama";
            this.tbox_nama.Size = new System.Drawing.Size(272, 19);
            this.tbox_nama.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(375, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 17);
            this.label5.TabIndex = 37;
            this.label5.Text = "Class";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.cbox_kelas);
            this.panel6.Location = new System.Drawing.Point(372, 142);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(304, 38);
            this.panel6.TabIndex = 36;
            // 
            // cbox_kelas
            // 
            this.cbox_kelas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_kelas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_kelas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_kelas.FormattingEnabled = true;
            this.cbox_kelas.Location = new System.Drawing.Point(9, 4);
            this.cbox_kelas.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_kelas.Name = "cbox_kelas";
            this.cbox_kelas.Size = new System.Drawing.Size(285, 29);
            this.cbox_kelas.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(375, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 35;
            this.label4.Text = "Address";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.tbox_alamat);
            this.panel5.Location = new System.Drawing.Point(372, 327);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(304, 80);
            this.panel5.TabIndex = 34;
            // 
            // tbox_alamat
            // 
            this.tbox_alamat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_alamat.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_alamat.Location = new System.Drawing.Point(8, 7);
            this.tbox_alamat.Multiline = true;
            this.tbox_alamat.Name = "tbox_alamat";
            this.tbox_alamat.Size = new System.Drawing.Size(287, 66);
            this.tbox_alamat.TabIndex = 0;
            this.tbox_alamat.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "NISN";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.tbox_nisn);
            this.panel4.Location = new System.Drawing.Point(34, 96);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(304, 38);
            this.panel4.TabIndex = 32;
            // 
            // tbox_nisn
            // 
            this.tbox_nisn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_nisn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_nisn.Location = new System.Drawing.Point(12, 9);
            this.tbox_nisn.Name = "tbox_nisn";
            this.tbox_nisn.Size = new System.Drawing.Size(272, 19);
            this.tbox_nisn.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.BorderSize = 2;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Green;
            this.button6.Location = new System.Drawing.Point(61, 679);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(126, 37);
            this.button6.TabIndex = 31;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Green;
            this.button7.FlatAppearance.BorderSize = 2;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(193, 679);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(126, 37);
            this.button7.TabIndex = 30;
            this.button7.Text = "Create";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 41);
            this.label1.TabIndex = 23;
            this.label1.Text = "Student";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.panel_not_found);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.check_showall);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.dgv_siswa);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(1, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(712, 787);
            this.panel3.TabIndex = 43;
            // 
            // panel_not_found
            // 
            this.panel_not_found.Controls.Add(this.label25);
            this.panel_not_found.Controls.Add(this.pictureBox1);
            this.panel_not_found.Location = new System.Drawing.Point(36, 234);
            this.panel_not_found.Name = "panel_not_found";
            this.panel_not_found.Size = new System.Drawing.Size(640, 318);
            this.panel_not_found.TabIndex = 80;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(272, 285);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 17);
            this.label25.TabIndex = 78;
            this.label25.Text = "Data not found ...";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(186, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(340, 282);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(19, 62);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(104, 17);
            this.label22.TabIndex = 44;
            this.label22.Text = "Search by class";
            // 
            // check_showall
            // 
            this.check_showall.AutoSize = true;
            this.check_showall.Location = new System.Drawing.Point(25, 125);
            this.check_showall.Name = "check_showall";
            this.check_showall.Size = new System.Drawing.Size(67, 17);
            this.check_showall.TabIndex = 34;
            this.check_showall.Text = "Show All";
            this.check_showall.UseVisualStyleBackColor = true;
            this.check_showall.CheckedChanged += new System.EventHandler(this.check_showall_CheckedChanged);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Green;
            this.button10.FlatAppearance.BorderSize = 2;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(565, 729);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(126, 37);
            this.button10.TabIndex = 33;
            this.button10.Text = "Activate";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.BorderSize = 2;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Green;
            this.button9.Location = new System.Drawing.Point(433, 729);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(126, 37);
            this.button9.TabIndex = 32;
            this.button9.Text = "Deactivate";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Green;
            this.button5.Location = new System.Drawing.Point(154, 729);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(126, 37);
            this.button5.TabIndex = 31;
            this.button5.Text = "Export Excel";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(22, 729);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(126, 37);
            this.button4.TabIndex = 30;
            this.button4.Text = "Detail";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dgv_siswa
            // 
            this.dgv_siswa.AllowUserToAddRows = false;
            this.dgv_siswa.AllowUserToDeleteRows = false;
            this.dgv_siswa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_siswa.BackgroundColor = System.Drawing.Color.White;
            this.dgv_siswa.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_siswa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_siswa.ColumnHeadersHeight = 60;
            this.dgv_siswa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_siswa.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_siswa.EnableHeadersVisualStyles = false;
            this.dgv_siswa.GridColor = System.Drawing.Color.Black;
            this.dgv_siswa.Location = new System.Drawing.Point(22, 165);
            this.dgv_siswa.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_siswa.MultiSelect = false;
            this.dgv_siswa.Name = "dgv_siswa";
            this.dgv_siswa.ReadOnly = true;
            this.dgv_siswa.RowHeadersVisible = false;
            this.dgv_siswa.RowHeadersWidth = 51;
            this.dgv_siswa.RowTemplate.Height = 50;
            this.dgv_siswa.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_siswa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_siswa.Size = new System.Drawing.Size(669, 551);
            this.dgv_siswa.TabIndex = 29;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Green;
            this.button3.Location = new System.Drawing.Point(301, 81);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(126, 37);
            this.button3.TabIndex = 28;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Green;
            this.button2.Location = new System.Drawing.Point(433, 81);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 37);
            this.button2.TabIndex = 27;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(565, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 37);
            this.button1.TabIndex = 26;
            this.button1.Text = "Create";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbox_search);
            this.panel1.Location = new System.Drawing.Point(22, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(208, 38);
            this.panel1.TabIndex = 25;
            // 
            // cbox_search
            // 
            this.cbox_search.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_search.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_search.FormattingEnabled = true;
            this.cbox_search.Location = new System.Drawing.Point(2, 4);
            this.cbox_search.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_search.Name = "cbox_search";
            this.cbox_search.Size = new System.Drawing.Size(202, 29);
            this.cbox_search.TabIndex = 43;
            this.cbox_search.SelectedIndexChanged += new System.EventHandler(this.cbox_search_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 41);
            this.label3.TabIndex = 23;
            this.label3.Text = "Student";
            // 
            // FormSiswa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1386, 787);
            this.Controls.Add(this.panel_detail);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSiswa";
            this.Text = "FormSiswa";
            this.Load += new System.EventHandler(this.FormSiswa_Load);
            this.panel_detail.ResumeLayout(false);
            this.panel_detail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel_not_found.ResumeLayout(false);
            this.panel_not_found.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_siswa)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_detail;
        private System.Windows.Forms.Label lb_status;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_kelas;
        private System.Windows.Forms.Label lb_created;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_nisn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox tbox_alamat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbox_nisn;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dgv_siswa;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox check_showall;
        private System.Windows.Forms.ComboBox cbox_search;
        private System.Windows.Forms.ComboBox cbox_kelas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox tbox_nama;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox cbox_spp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lb_spp;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lb_alamat;
        private System.Windows.Forms.Label lb_nis;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox tbox_nis;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DateTimePicker dtpick_lahir;
        private System.Windows.Forms.PictureBox pb_foto;
        private System.Windows.Forms.Label lb_kelamin;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lb_lahir;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton rb_perempuan;
        private System.Windows.Forms.RadioButton rb_laki;
        private System.Windows.Forms.PictureBox pb_foto_detail;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label lb_nominal;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lb_telp;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbox_telp;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel_not_found;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
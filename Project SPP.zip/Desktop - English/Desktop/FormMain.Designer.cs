﻿
namespace Desktop
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_riwayat = new System.Windows.Forms.Button();
            this.btn_petugas = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btn_siswa = new System.Windows.Forms.Button();
            this.btn_spp = new System.Windows.Forms.Button();
            this.btn_kelas = new System.Windows.Forms.Button();
            this.btn_pembayaran = new System.Windows.Forms.Button();
            this.btn_dashboard = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.pb_foto = new System.Windows.Forms.PictureBox();
            this.lb_role = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_main = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1178, -1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(43, 38);
            this.button2.TabIndex = 2;
            this.button2.Text = "x";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.31162F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.68838F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel_main, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(103, -1);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1013, 792);
            this.tableLayoutPanel1.TabIndex = 3;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btn_riwayat);
            this.panel1.Controls.Add(this.btn_petugas);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.btn_siswa);
            this.panel1.Controls.Add(this.btn_spp);
            this.panel1.Controls.Add(this.btn_kelas);
            this.panel1.Controls.Add(this.btn_pembayaran);
            this.panel1.Controls.Add(this.btn_dashboard);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lb_nama);
            this.panel1.Controls.Add(this.pb_foto);
            this.panel1.Controls.Add(this.lb_role);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(285, 788);
            this.panel1.TabIndex = 0;
            // 
            // btn_riwayat
            // 
            this.btn_riwayat.BackColor = System.Drawing.Color.Green;
            this.btn_riwayat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_riwayat.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_riwayat.ForeColor = System.Drawing.Color.White;
            this.btn_riwayat.Location = new System.Drawing.Point(12, 295);
            this.btn_riwayat.Margin = new System.Windows.Forms.Padding(2);
            this.btn_riwayat.Name = "btn_riwayat";
            this.btn_riwayat.Size = new System.Drawing.Size(262, 49);
            this.btn_riwayat.TabIndex = 20;
            this.btn_riwayat.Text = "Payment History";
            this.btn_riwayat.UseVisualStyleBackColor = false;
            this.btn_riwayat.Click += new System.EventHandler(this.btn_riwayat_Click);
            // 
            // btn_petugas
            // 
            this.btn_petugas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_petugas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_petugas.ForeColor = System.Drawing.Color.Green;
            this.btn_petugas.Location = new System.Drawing.Point(12, 616);
            this.btn_petugas.Margin = new System.Windows.Forms.Padding(2);
            this.btn_petugas.Name = "btn_petugas";
            this.btn_petugas.Size = new System.Drawing.Size(262, 49);
            this.btn_petugas.TabIndex = 18;
            this.btn_petugas.Text = "Staff";
            this.btn_petugas.UseVisualStyleBackColor = true;
            this.btn_petugas.Click += new System.EventHandler(this.btn_petugas_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Green;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(12, 723);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(262, 49);
            this.button8.TabIndex = 17;
            this.button8.Text = "Log Out";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn_siswa
            // 
            this.btn_siswa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_siswa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_siswa.ForeColor = System.Drawing.Color.Green;
            this.btn_siswa.Location = new System.Drawing.Point(12, 454);
            this.btn_siswa.Margin = new System.Windows.Forms.Padding(2);
            this.btn_siswa.Name = "btn_siswa";
            this.btn_siswa.Size = new System.Drawing.Size(262, 49);
            this.btn_siswa.TabIndex = 16;
            this.btn_siswa.Text = "Students";
            this.btn_siswa.UseVisualStyleBackColor = true;
            this.btn_siswa.Click += new System.EventHandler(this.btn_siswa_Click);
            // 
            // btn_spp
            // 
            this.btn_spp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_spp.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_spp.ForeColor = System.Drawing.Color.Green;
            this.btn_spp.Location = new System.Drawing.Point(12, 507);
            this.btn_spp.Margin = new System.Windows.Forms.Padding(2);
            this.btn_spp.Name = "btn_spp";
            this.btn_spp.Size = new System.Drawing.Size(262, 49);
            this.btn_spp.TabIndex = 15;
            this.btn_spp.Text = "Fee";
            this.btn_spp.UseVisualStyleBackColor = true;
            this.btn_spp.Click += new System.EventHandler(this.btn_spp_Click);
            // 
            // btn_kelas
            // 
            this.btn_kelas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kelas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kelas.ForeColor = System.Drawing.Color.Green;
            this.btn_kelas.Location = new System.Drawing.Point(12, 563);
            this.btn_kelas.Margin = new System.Windows.Forms.Padding(2);
            this.btn_kelas.Name = "btn_kelas";
            this.btn_kelas.Size = new System.Drawing.Size(262, 49);
            this.btn_kelas.TabIndex = 14;
            this.btn_kelas.Text = "Class";
            this.btn_kelas.UseVisualStyleBackColor = true;
            this.btn_kelas.Click += new System.EventHandler(this.btn_kelas_Click);
            // 
            // btn_pembayaran
            // 
            this.btn_pembayaran.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pembayaran.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pembayaran.ForeColor = System.Drawing.Color.Green;
            this.btn_pembayaran.Location = new System.Drawing.Point(12, 401);
            this.btn_pembayaran.Margin = new System.Windows.Forms.Padding(2);
            this.btn_pembayaran.Name = "btn_pembayaran";
            this.btn_pembayaran.Size = new System.Drawing.Size(262, 49);
            this.btn_pembayaran.TabIndex = 13;
            this.btn_pembayaran.Text = "Payment";
            this.btn_pembayaran.UseVisualStyleBackColor = true;
            this.btn_pembayaran.Click += new System.EventHandler(this.btn_pembayaran_Click);
            // 
            // btn_dashboard
            // 
            this.btn_dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dashboard.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dashboard.ForeColor = System.Drawing.Color.Green;
            this.btn_dashboard.Location = new System.Drawing.Point(12, 348);
            this.btn_dashboard.Margin = new System.Windows.Forms.Padding(2);
            this.btn_dashboard.Name = "btn_dashboard";
            this.btn_dashboard.Size = new System.Drawing.Size(262, 49);
            this.btn_dashboard.TabIndex = 11;
            this.btn_dashboard.Text = "Dashboard";
            this.btn_dashboard.UseVisualStyleBackColor = true;
            this.btn_dashboard.Click += new System.EventHandler(this.btn_dashboard_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 249);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "datetime";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_nama
            // 
            this.lb_nama.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama.Location = new System.Drawing.Point(3, 225);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(279, 24);
            this.lb_nama.TabIndex = 9;
            this.lb_nama.Text = "Nama";
            this.lb_nama.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_foto
            // 
            this.pb_foto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto.Location = new System.Drawing.Point(92, 85);
            this.pb_foto.Margin = new System.Windows.Forms.Padding(2);
            this.pb_foto.Name = "pb_foto";
            this.pb_foto.Size = new System.Drawing.Size(100, 100);
            this.pb_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto.TabIndex = 8;
            this.pb_foto.TabStop = false;
            // 
            // lb_role
            // 
            this.lb_role.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_role.Location = new System.Drawing.Point(3, 201);
            this.lb_role.Name = "lb_role";
            this.lb_role.Size = new System.Drawing.Size(279, 24);
            this.lb_role.TabIndex = 7;
            this.lb_role.Text = "Role";
            this.lb_role.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Green;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(285, 131);
            this.panel2.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(104, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 35);
            this.label3.TabIndex = 5;
            this.label3.Text = "SPP";
            // 
            // panel_main
            // 
            this.panel_main.BackColor = System.Drawing.Color.White;
            this.panel_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_main.Location = new System.Drawing.Point(298, 2);
            this.panel_main.Margin = new System.Windows.Forms.Padding(2);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(713, 788);
            this.panel_main.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1220, 788);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.button2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_role;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_dashboard;
        private System.Windows.Forms.Button btn_pembayaran;
        private System.Windows.Forms.Button btn_kelas;
        private System.Windows.Forms.Button btn_spp;
        private System.Windows.Forms.Button btn_siswa;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btn_petugas;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pb_foto;
        private System.Windows.Forms.Button btn_riwayat;
    }
}
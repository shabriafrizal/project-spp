﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormMain : Form
    {
        Helper helper = new Helper();
        public FormMain()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            if(Session_login.role == "admin")
            {
                btn_dashboard_Click(sender, e);
                btn_riwayat.Hide();
            }
            else if(Session_login.role == "staff")
            {
                btn_dashboard_Click(sender, e);
                btn_riwayat.Hide();
                btn_kelas.Hide();
                btn_spp.Hide();
                btn_siswa.Hide();
                btn_petugas.Hide();
            }
            else if(Session_login.role == "student")
            {
                btn_riwayat_Click(sender, e);
                btn_dashboard.Hide();
                btn_pembayaran.Hide();
                btn_kelas.Hide();
                btn_spp.Hide();
                btn_siswa.Hide();
                btn_petugas.Hide();
            }

            lb_nama.Text = Session_login.nama;
            lb_role.Text = Session_login.role;
            if (Session_login.foto == null)
            {
                pb_foto.Image = null;
            }
            else
            {
                pb_foto.Image = helper.ByteToImage(Session_login.foto);
            }
        }

        private void ColorNav()
        {
            btn_dashboard.ForeColor = Color.Green;
            btn_dashboard.BackColor = Color.White;
            btn_pembayaran.ForeColor = Color.Green;
            btn_pembayaran.BackColor = Color.White;
            btn_kelas.ForeColor = Color.Green;
            btn_kelas.BackColor = Color.White;
            btn_spp.ForeColor = Color.Green;
            btn_spp.BackColor = Color.White;
            btn_siswa.ForeColor = Color.Green;
            btn_siswa.BackColor = Color.White;
            btn_petugas.ForeColor = Color.Green;
            btn_petugas.BackColor = Color.White;
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormDashboard(), panel_main);
            ColorNav();
            btn_dashboard.ForeColor = Color.White;
            btn_dashboard.BackColor = Color.Green;
        }

        private void btn_pembayaran_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormPembayaran(), panel_main);
            ColorNav();
            btn_pembayaran.ForeColor = Color.White;
            btn_pembayaran.BackColor = Color.Green;
        }

        private void btn_kelas_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormKelas(), panel_main);
            ColorNav();
            btn_kelas.ForeColor = Color.White;
            btn_kelas.BackColor = Color.Green;
        }

        private void btn_spp_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormSpp(), panel_main);
            ColorNav();
            btn_spp.ForeColor = Color.White;
            btn_spp.BackColor = Color.Green;
        }

        private void btn_siswa_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormSiswa(), panel_main);
            ColorNav();
            btn_siswa.ForeColor = Color.White;
            btn_siswa.BackColor = Color.Green;
        }

        private void btn_petugas_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormPetugas(), panel_main);
            ColorNav();
            btn_petugas.ForeColor = Color.White;
            btn_petugas.BackColor = Color.Green;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure?", "Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Form1 obj = new Form1();
                obj.Show();
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_riwayat_Click(object sender, EventArgs e)
        {
            helper.OpenForm(new FormRiwayat(), panel_main);
        }
    }
}

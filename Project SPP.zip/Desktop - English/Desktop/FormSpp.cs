﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormSpp : Form
    {
        int id = 0;
        Helper helper = new Helper();

        public FormSpp()
        {
            InitializeComponent();
        }
        private void FormSpp_Load(object sender, EventArgs e)
        {
            panel2.Location = new Point(0, 0);
            panel2.Hide();

            panel_detail.Location = new Point(0, 0);
            panel_detail.Hide();

            LoadDgv();
        }

        private void LoadDgv()
        {
            dgv_spp.DataSource = helper.GetTable("Select id as ID, tahun as [School year], keterangan as Information, nominal as Nominal from tbl_spp");
            if (dgv_spp.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Show();

            id = 0;
            tbox_tahun.Text = "";
            tbox_keterangan.Text = "";
            num_nominal.Value = 0;

            button7.Text = "Create";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            panel1.Hide();
            panel2.Show();

            id = int.Parse(dgv_spp.Rows[dgv_spp.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select * from tbl_spp where id = {id}");
            DataRow row = dt.Rows[0];
            tbox_keterangan.Text = row["keterangan"].ToString();
            tbox_tahun.Text = row["tahun"].ToString();
            num_nominal.Value = int.Parse(row["nominal"].ToString());

            button7.Text = "Change";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (helper.LengthMax(tbox_tahun, 4, "Tahun") == 0 || helper.LengthMin(tbox_tahun, 4, "Tahun") == 0)
            {
                return;
            }

            if (id == 0)
            {
                string query = $"Insert into tbl_spp values(" +
                    $"'{tbox_tahun.Text}'," +
                    $"'{num_nominal.Value}'," +
                    $"'{tbox_tahun.Text} {tbox_keterangan.Text}'," +
                    $"1," +
                    $"@datenow," +
                    $"@datenow)";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);
                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data created successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
            else
            {
                string query = $"Update tbl_spp set " +
                   $"tahun='{tbox_tahun.Text}'," +
                   $"nominal='{num_nominal.Value}'," +
                   $"keterangan='{tbox_keterangan.Text}'," +
                   $"last_updated=@datenow" +
                   $" where id = {id}";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);
                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data changed successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            panel1.Hide();
            panel_detail.Show();

            id = int.Parse(dgv_spp.Rows[dgv_spp.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"select * from tbl_spp where id = {id}");
            DataRow row = dt.Rows[0];
            lb_tahun.Text = row["tahun"].ToString();
            lb_nominal.Text = row["nominal"].ToString();
            lb_keterangan.Text = row["keterangan"].ToString();
            lb_created.Text = row["created_at"].ToString();
            if (int.Parse(row["status"].ToString()) == 0)
            {
                lb_status.Text = "Tidak Aktif";
            }
            if (int.Parse(row["status"].ToString()) == 1)
            {
                lb_status.Text = "Aktif";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel_detail.Hide();
            panel1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            helper.ExportExcel(helper.GetTable("select id as ID, tahun as Tahun, keterangan as Keterangan, nominal As Nominal from tbl_spp"));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Delete This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_spp.Rows[dgv_spp.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Delete from tbl_spp where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data is still in use.");
                    return;
                }
                MessageBox.Show("Data successfully deleted");
                LoadDgv();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Enable This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_spp.Rows[dgv_spp.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_spp set status=1 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dgv_spp.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Disable This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_spp.Rows[dgv_spp.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_spp set status=0 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void tbox_search_TextChanged(object sender, EventArgs e)
        {
            SearchDgv();
        }

        private void SearchDgv()
        {
            dgv_spp.DataSource = helper.GetTable($"Select id as ID, tahun as [School year], keterangan as Information, nominal as Nominal from tbl_spp where id like '%{tbox_search.Text}%' or tahun like '%{tbox_search.Text}%' or keterangan like '%{tbox_search.Text}%' or nominal like '%{tbox_search.Text}%'");
            if (dgv_spp.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }
    }
}

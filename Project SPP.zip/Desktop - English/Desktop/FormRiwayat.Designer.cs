﻿namespace Desktop
{
    partial class FormRiwayat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRiwayat));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_detail = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel_not_found = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.check_spp_detail = new System.Windows.Forms.CheckBox();
            this.cbox_spp_detail = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.check_bulan_detail = new System.Windows.Forms.CheckBox();
            this.cbox_bulan_detail = new System.Windows.Forms.ComboBox();
            this.check_showall_detail = new System.Windows.Forms.CheckBox();
            this.dgv_history_pembayaraan = new System.Windows.Forms.DataGridView();
            this.pb_foto_detail = new System.Windows.Forms.PictureBox();
            this.lb_nis = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_kelas = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel_detail2 = new System.Windows.Forms.Panel();
            this.lb_tanggungan_detail2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lb_status_detail2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dgv_history_pembayaran_detail2 = new System.Windows.Forms.DataGridView();
            this.lb_kategori_detail2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lb_nama_detail2 = new System.Windows.Forms.Label();
            this.lb_bulan_detail2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel_cek = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.lb_december = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.lb_august = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.lb_april = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.lb_november = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.lb_july = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.lb_march = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.lb_october = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.lb_june = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.lb_february = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.lb_september = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.lb_may = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.lb_january = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.cbox_spp_cek = new System.Windows.Forms.ComboBox();
            this.rb_tahun_lainnya_cek = new System.Windows.Forms.RadioButton();
            this.rb_tahun_ini_cek = new System.Windows.Forms.RadioButton();
            this.lb_nominal_cek = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lb_nama_cek = new System.Windows.Forms.Label();
            this.lb_kategori_cek = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.panel_detail.SuspendLayout();
            this.panel_not_found.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaraan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).BeginInit();
            this.panel_detail2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaran_detail2)).BeginInit();
            this.panel_cek.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_detail
            // 
            this.panel_detail.BackColor = System.Drawing.Color.White;
            this.panel_detail.Controls.Add(this.button1);
            this.panel_detail.Controls.Add(this.panel_not_found);
            this.panel_detail.Controls.Add(this.button5);
            this.panel_detail.Controls.Add(this.label7);
            this.panel_detail.Controls.Add(this.panel10);
            this.panel_detail.Controls.Add(this.panel9);
            this.panel_detail.Controls.Add(this.check_showall_detail);
            this.panel_detail.Controls.Add(this.dgv_history_pembayaraan);
            this.panel_detail.Controls.Add(this.pb_foto_detail);
            this.panel_detail.Controls.Add(this.lb_nis);
            this.panel_detail.Controls.Add(this.label17);
            this.panel_detail.Controls.Add(this.lb_nama);
            this.panel_detail.Controls.Add(this.lb_kelas);
            this.panel_detail.Controls.Add(this.label8);
            this.panel_detail.Controls.Add(this.label10);
            this.panel_detail.Controls.Add(this.label11);
            this.panel_detail.Location = new System.Drawing.Point(0, 0);
            this.panel_detail.Margin = new System.Windows.Forms.Padding(2);
            this.panel_detail.Name = "panel_detail";
            this.panel_detail.Size = new System.Drawing.Size(712, 787);
            this.panel_detail.TabIndex = 49;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(433, 684);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 37);
            this.button1.TabIndex = 82;
            this.button1.Text = "Check paid";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel_not_found
            // 
            this.panel_not_found.Controls.Add(this.label25);
            this.panel_not_found.Controls.Add(this.pictureBox1);
            this.panel_not_found.Location = new System.Drawing.Point(36, 449);
            this.panel_not_found.Name = "panel_not_found";
            this.panel_not_found.Size = new System.Drawing.Size(640, 148);
            this.panel_not_found.TabIndex = 81;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(255, 123);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 17);
            this.label25.TabIndex = 78;
            this.label25.Text = "Data not found ...";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(174, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(340, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Green;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(565, 684);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(126, 37);
            this.button5.TabIndex = 68;
            this.button5.Text = "History";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 262);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 17);
            this.label7.TabIndex = 66;
            this.label7.Text = "Search";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.check_spp_detail);
            this.panel10.Controls.Add(this.cbox_spp_detail);
            this.panel10.Location = new System.Drawing.Point(344, 282);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(347, 38);
            this.panel10.TabIndex = 65;
            // 
            // check_spp_detail
            // 
            this.check_spp_detail.AutoSize = true;
            this.check_spp_detail.Location = new System.Drawing.Point(319, 12);
            this.check_spp_detail.Name = "check_spp_detail";
            this.check_spp_detail.Size = new System.Drawing.Size(15, 14);
            this.check_spp_detail.TabIndex = 69;
            this.check_spp_detail.UseVisualStyleBackColor = true;
            this.check_spp_detail.CheckedChanged += new System.EventHandler(this.check_spp_detail_CheckedChanged);
            // 
            // cbox_spp_detail
            // 
            this.cbox_spp_detail.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp_detail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp_detail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp_detail.FormattingEnabled = true;
            this.cbox_spp_detail.Location = new System.Drawing.Point(9, 4);
            this.cbox_spp_detail.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp_detail.Name = "cbox_spp_detail";
            this.cbox_spp_detail.Size = new System.Drawing.Size(300, 29);
            this.cbox_spp_detail.TabIndex = 43;
            this.cbox_spp_detail.SelectedIndexChanged += new System.EventHandler(this.cbox_spp_detail_SelectedIndexChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.check_bulan_detail);
            this.panel9.Controls.Add(this.cbox_bulan_detail);
            this.panel9.Location = new System.Drawing.Point(22, 282);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(316, 38);
            this.panel9.TabIndex = 64;
            // 
            // check_bulan_detail
            // 
            this.check_bulan_detail.AutoSize = true;
            this.check_bulan_detail.Location = new System.Drawing.Point(288, 12);
            this.check_bulan_detail.Name = "check_bulan_detail";
            this.check_bulan_detail.Size = new System.Drawing.Size(15, 14);
            this.check_bulan_detail.TabIndex = 68;
            this.check_bulan_detail.UseVisualStyleBackColor = true;
            this.check_bulan_detail.CheckedChanged += new System.EventHandler(this.check_bulan_detail_CheckedChanged);
            // 
            // cbox_bulan_detail
            // 
            this.cbox_bulan_detail.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_bulan_detail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_bulan_detail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_bulan_detail.FormattingEnabled = true;
            this.cbox_bulan_detail.Location = new System.Drawing.Point(9, 4);
            this.cbox_bulan_detail.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_bulan_detail.Name = "cbox_bulan_detail";
            this.cbox_bulan_detail.Size = new System.Drawing.Size(269, 29);
            this.cbox_bulan_detail.TabIndex = 43;
            this.cbox_bulan_detail.SelectedIndexChanged += new System.EventHandler(this.cbox_bulan_detail_SelectedIndexChanged);
            // 
            // check_showall_detail
            // 
            this.check_showall_detail.AutoSize = true;
            this.check_showall_detail.Location = new System.Drawing.Point(31, 328);
            this.check_showall_detail.Name = "check_showall_detail";
            this.check_showall_detail.Size = new System.Drawing.Size(67, 17);
            this.check_showall_detail.TabIndex = 63;
            this.check_showall_detail.Text = "Show All";
            this.check_showall_detail.UseVisualStyleBackColor = true;
            this.check_showall_detail.CheckedChanged += new System.EventHandler(this.check_showall_detail_CheckedChanged);
            // 
            // dgv_history_pembayaraan
            // 
            this.dgv_history_pembayaraan.AllowUserToAddRows = false;
            this.dgv_history_pembayaraan.AllowUserToDeleteRows = false;
            this.dgv_history_pembayaraan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_history_pembayaraan.BackgroundColor = System.Drawing.Color.White;
            this.dgv_history_pembayaraan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_history_pembayaraan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_history_pembayaraan.ColumnHeadersHeight = 60;
            this.dgv_history_pembayaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaraan.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_history_pembayaraan.EnableHeadersVisualStyles = false;
            this.dgv_history_pembayaraan.GridColor = System.Drawing.Color.Black;
            this.dgv_history_pembayaraan.Location = new System.Drawing.Point(22, 356);
            this.dgv_history_pembayaraan.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_history_pembayaraan.MultiSelect = false;
            this.dgv_history_pembayaraan.Name = "dgv_history_pembayaraan";
            this.dgv_history_pembayaraan.ReadOnly = true;
            this.dgv_history_pembayaraan.RowHeadersVisible = false;
            this.dgv_history_pembayaraan.RowHeadersWidth = 51;
            this.dgv_history_pembayaraan.RowTemplate.Height = 50;
            this.dgv_history_pembayaraan.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaraan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_history_pembayaraan.Size = new System.Drawing.Size(669, 316);
            this.dgv_history_pembayaraan.TabIndex = 57;
            this.dgv_history_pembayaraan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_history_pembayaraan_CellContentClick);
            // 
            // pb_foto_detail
            // 
            this.pb_foto_detail.BackColor = System.Drawing.Color.White;
            this.pb_foto_detail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto_detail.Location = new System.Drawing.Point(525, 41);
            this.pb_foto_detail.Name = "pb_foto_detail";
            this.pb_foto_detail.Size = new System.Drawing.Size(120, 120);
            this.pb_foto_detail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto_detail.TabIndex = 56;
            this.pb_foto_detail.TabStop = false;
            // 
            // lb_nis
            // 
            this.lb_nis.AutoSize = true;
            this.lb_nis.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nis.ForeColor = System.Drawing.Color.Black;
            this.lb_nis.Location = new System.Drawing.Point(380, 222);
            this.lb_nis.Name = "lb_nis";
            this.lb_nis.Size = new System.Drawing.Size(52, 25);
            this.lb_nis.TabIndex = 51;
            this.lb_nis.Text = "Text";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(377, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(27, 17);
            this.label17.TabIndex = 50;
            this.label17.Text = "NIS";
            // 
            // lb_nama
            // 
            this.lb_nama.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama.ForeColor = System.Drawing.Color.Black;
            this.lb_nama.Location = new System.Drawing.Point(41, 149);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(454, 25);
            this.lb_nama.TabIndex = 41;
            this.lb_nama.Text = "Text";
            // 
            // lb_kelas
            // 
            this.lb_kelas.AutoSize = true;
            this.lb_kelas.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kelas.ForeColor = System.Drawing.Color.Black;
            this.lb_kelas.Location = new System.Drawing.Point(41, 221);
            this.lb_kelas.Name = "lb_kelas";
            this.lb_kelas.Size = new System.Drawing.Size(52, 25);
            this.lb_kelas.TabIndex = 40;
            this.lb_kelas.Text = "Text";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(38, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(38, 198);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 17);
            this.label10.TabIndex = 33;
            this.label10.Text = "Class";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(311, 41);
            this.label11.TabIndex = 23;
            this.label11.Text = "Payment History";
            // 
            // panel_detail2
            // 
            this.panel_detail2.BackColor = System.Drawing.Color.White;
            this.panel_detail2.Controls.Add(this.lb_tanggungan_detail2);
            this.panel_detail2.Controls.Add(this.label20);
            this.panel_detail2.Controls.Add(this.lb_status_detail2);
            this.panel_detail2.Controls.Add(this.label14);
            this.panel_detail2.Controls.Add(this.dgv_history_pembayaran_detail2);
            this.panel_detail2.Controls.Add(this.lb_kategori_detail2);
            this.panel_detail2.Controls.Add(this.label13);
            this.panel_detail2.Controls.Add(this.lb_nama_detail2);
            this.panel_detail2.Controls.Add(this.lb_bulan_detail2);
            this.panel_detail2.Controls.Add(this.label16);
            this.panel_detail2.Controls.Add(this.label18);
            this.panel_detail2.Controls.Add(this.button9);
            this.panel_detail2.Controls.Add(this.label19);
            this.panel_detail2.Location = new System.Drawing.Point(733, 19);
            this.panel_detail2.Margin = new System.Windows.Forms.Padding(2);
            this.panel_detail2.Name = "panel_detail2";
            this.panel_detail2.Size = new System.Drawing.Size(712, 787);
            this.panel_detail2.TabIndex = 74;
            // 
            // lb_tanggungan_detail2
            // 
            this.lb_tanggungan_detail2.AutoSize = true;
            this.lb_tanggungan_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tanggungan_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_tanggungan_detail2.Location = new System.Drawing.Point(381, 282);
            this.lb_tanggungan_detail2.Name = "lb_tanggungan_detail2";
            this.lb_tanggungan_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_tanggungan_detail2.TabIndex = 71;
            this.lb_tanggungan_detail2.Text = "Text";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(378, 259);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 17);
            this.label20.TabIndex = 70;
            this.label20.Text = "Dependents";
            // 
            // lb_status_detail2
            // 
            this.lb_status_detail2.AutoSize = true;
            this.lb_status_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_status_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_status_detail2.Location = new System.Drawing.Point(42, 282);
            this.lb_status_detail2.Name = "lb_status_detail2";
            this.lb_status_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_status_detail2.TabIndex = 69;
            this.lb_status_detail2.Text = "Text";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(39, 259);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 17);
            this.label14.TabIndex = 68;
            this.label14.Text = "Status";
            // 
            // dgv_history_pembayaran_detail2
            // 
            this.dgv_history_pembayaran_detail2.AllowUserToAddRows = false;
            this.dgv_history_pembayaran_detail2.AllowUserToDeleteRows = false;
            this.dgv_history_pembayaran_detail2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_history_pembayaran_detail2.BackgroundColor = System.Drawing.Color.White;
            this.dgv_history_pembayaran_detail2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_history_pembayaran_detail2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_history_pembayaran_detail2.ColumnHeadersHeight = 60;
            this.dgv_history_pembayaran_detail2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaran_detail2.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_history_pembayaran_detail2.EnableHeadersVisualStyles = false;
            this.dgv_history_pembayaran_detail2.GridColor = System.Drawing.Color.Black;
            this.dgv_history_pembayaran_detail2.Location = new System.Drawing.Point(22, 356);
            this.dgv_history_pembayaran_detail2.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_history_pembayaran_detail2.MultiSelect = false;
            this.dgv_history_pembayaran_detail2.Name = "dgv_history_pembayaran_detail2";
            this.dgv_history_pembayaran_detail2.ReadOnly = true;
            this.dgv_history_pembayaran_detail2.RowHeadersVisible = false;
            this.dgv_history_pembayaran_detail2.RowHeadersWidth = 51;
            this.dgv_history_pembayaran_detail2.RowTemplate.Height = 50;
            this.dgv_history_pembayaran_detail2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaran_detail2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_history_pembayaran_detail2.Size = new System.Drawing.Size(669, 316);
            this.dgv_history_pembayaran_detail2.TabIndex = 57;
            // 
            // lb_kategori_detail2
            // 
            this.lb_kategori_detail2.AutoSize = true;
            this.lb_kategori_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori_detail2.Location = new System.Drawing.Point(381, 199);
            this.lb_kategori_detail2.Name = "lb_kategori_detail2";
            this.lb_kategori_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori_detail2.TabIndex = 51;
            this.lb_kategori_detail2.Text = "Text";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(378, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 17);
            this.label13.TabIndex = 50;
            this.label13.Text = "Fee category";
            // 
            // lb_nama_detail2
            // 
            this.lb_nama_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_nama_detail2.Location = new System.Drawing.Point(41, 111);
            this.lb_nama_detail2.Name = "lb_nama_detail2";
            this.lb_nama_detail2.Size = new System.Drawing.Size(454, 25);
            this.lb_nama_detail2.TabIndex = 41;
            this.lb_nama_detail2.Text = "Text";
            // 
            // lb_bulan_detail2
            // 
            this.lb_bulan_detail2.AutoSize = true;
            this.lb_bulan_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_bulan_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_bulan_detail2.Location = new System.Drawing.Point(42, 198);
            this.lb_bulan_detail2.Name = "lb_bulan_detail2";
            this.lb_bulan_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_bulan_detail2.TabIndex = 40;
            this.lb_bulan_detail2.Text = "Text";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(38, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 17);
            this.label16.TabIndex = 37;
            this.label16.Text = "Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(39, 175);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 17);
            this.label18.TabIndex = 33;
            this.label18.Text = "Month";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.BorderSize = 2;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Green;
            this.button9.Location = new System.Drawing.Point(22, 685);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(126, 37);
            this.button9.TabIndex = 31;
            this.button9.Text = "Back";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(15, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(311, 41);
            this.label19.TabIndex = 23;
            this.label19.Text = "Payment History";
            // 
            // panel_cek
            // 
            this.panel_cek.BackColor = System.Drawing.Color.White;
            this.panel_cek.Controls.Add(this.tableLayoutPanel1);
            this.panel_cek.Controls.Add(this.panel13);
            this.panel_cek.Controls.Add(this.rb_tahun_lainnya_cek);
            this.panel_cek.Controls.Add(this.rb_tahun_ini_cek);
            this.panel_cek.Controls.Add(this.lb_nominal_cek);
            this.panel_cek.Controls.Add(this.label29);
            this.panel_cek.Controls.Add(this.lb_nama_cek);
            this.panel_cek.Controls.Add(this.lb_kategori_cek);
            this.panel_cek.Controls.Add(this.label32);
            this.panel_cek.Controls.Add(this.label33);
            this.panel_cek.Controls.Add(this.button19);
            this.panel_cek.Controls.Add(this.label34);
            this.panel_cek.Location = new System.Drawing.Point(755, 0);
            this.panel_cek.Margin = new System.Windows.Forms.Padding(2);
            this.panel_cek.Name = "panel_cek";
            this.panel_cek.Size = new System.Drawing.Size(712, 787);
            this.panel_cek.TabIndex = 85;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.panel25, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel22, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel20, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel14, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-36, 271);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(664, 429);
            this.tableLayoutPanel1.TabIndex = 60;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label49);
            this.panel25.Controls.Add(this.lb_december);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(445, 324);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(216, 102);
            this.panel25.TabIndex = 11;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(81, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(76, 17);
            this.label49.TabIndex = 54;
            this.label49.Text = "December";
            // 
            // lb_december
            // 
            this.lb_december.AutoSize = true;
            this.lb_december.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_december.ForeColor = System.Drawing.Color.Green;
            this.lb_december.Location = new System.Drawing.Point(84, 50);
            this.lb_december.Name = "lb_december";
            this.lb_december.Size = new System.Drawing.Size(47, 23);
            this.lb_december.TabIndex = 55;
            this.lb_december.Text = "Text";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label47);
            this.panel24.Controls.Add(this.lb_august);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(224, 324);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(215, 102);
            this.panel24.TabIndex = 10;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(80, 27);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(52, 17);
            this.label47.TabIndex = 54;
            this.label47.Text = "August";
            // 
            // lb_august
            // 
            this.lb_august.AutoSize = true;
            this.lb_august.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_august.ForeColor = System.Drawing.Color.Green;
            this.lb_august.Location = new System.Drawing.Point(83, 50);
            this.lb_august.Name = "lb_august";
            this.lb_august.Size = new System.Drawing.Size(47, 23);
            this.lb_august.TabIndex = 55;
            this.lb_august.Text = "Text";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label51);
            this.panel23.Controls.Add(this.lb_april);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(3, 324);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(215, 102);
            this.panel23.TabIndex = 9;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(80, 27);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(36, 17);
            this.label51.TabIndex = 54;
            this.label51.Text = "April";
            // 
            // lb_april
            // 
            this.lb_april.AutoSize = true;
            this.lb_april.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_april.ForeColor = System.Drawing.Color.Green;
            this.lb_april.Location = new System.Drawing.Point(83, 50);
            this.lb_april.Name = "lb_april";
            this.lb_april.Size = new System.Drawing.Size(47, 23);
            this.lb_april.TabIndex = 55;
            this.lb_april.Text = "Text";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label45);
            this.panel22.Controls.Add(this.lb_november);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(445, 217);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(216, 101);
            this.panel22.TabIndex = 8;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(81, 26);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(77, 17);
            this.label45.TabIndex = 54;
            this.label45.Text = "November";
            // 
            // lb_november
            // 
            this.lb_november.AutoSize = true;
            this.lb_november.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_november.ForeColor = System.Drawing.Color.Green;
            this.lb_november.Location = new System.Drawing.Point(84, 49);
            this.lb_november.Name = "lb_november";
            this.lb_november.Size = new System.Drawing.Size(47, 23);
            this.lb_november.TabIndex = 55;
            this.lb_november.Text = "Text";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.label43);
            this.panel21.Controls.Add(this.lb_july);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(224, 217);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(215, 101);
            this.panel21.TabIndex = 7;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(80, 26);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(31, 17);
            this.label43.TabIndex = 54;
            this.label43.Text = "July";
            // 
            // lb_july
            // 
            this.lb_july.AutoSize = true;
            this.lb_july.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_july.ForeColor = System.Drawing.Color.Green;
            this.lb_july.Location = new System.Drawing.Point(83, 49);
            this.lb_july.Name = "lb_july";
            this.lb_july.Size = new System.Drawing.Size(47, 23);
            this.lb_july.TabIndex = 55;
            this.lb_july.Text = "Text";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label41);
            this.panel20.Controls.Add(this.lb_march);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(3, 217);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(215, 101);
            this.panel20.TabIndex = 6;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(80, 26);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(48, 17);
            this.label41.TabIndex = 54;
            this.label41.Text = "March";
            // 
            // lb_march
            // 
            this.lb_march.AutoSize = true;
            this.lb_march.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_march.ForeColor = System.Drawing.Color.Green;
            this.lb_march.Location = new System.Drawing.Point(83, 49);
            this.lb_march.Name = "lb_march";
            this.lb_march.Size = new System.Drawing.Size(47, 23);
            this.lb_march.TabIndex = 55;
            this.lb_march.Text = "Text";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label35);
            this.panel19.Controls.Add(this.lb_october);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(445, 110);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(216, 101);
            this.panel19.TabIndex = 5;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(81, 26);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 17);
            this.label35.TabIndex = 54;
            this.label35.Text = "October";
            // 
            // lb_october
            // 
            this.lb_october.AutoSize = true;
            this.lb_october.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_october.ForeColor = System.Drawing.Color.Green;
            this.lb_october.Location = new System.Drawing.Point(84, 49);
            this.lb_october.Name = "lb_october";
            this.lb_october.Size = new System.Drawing.Size(47, 23);
            this.lb_october.TabIndex = 55;
            this.lb_october.Text = "Text";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label37);
            this.panel18.Controls.Add(this.lb_june);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(224, 110);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(215, 101);
            this.panel18.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(80, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(38, 17);
            this.label37.TabIndex = 54;
            this.label37.Text = "June";
            // 
            // lb_june
            // 
            this.lb_june.AutoSize = true;
            this.lb_june.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_june.ForeColor = System.Drawing.Color.Green;
            this.lb_june.Location = new System.Drawing.Point(83, 49);
            this.lb_june.Name = "lb_june";
            this.lb_june.Size = new System.Drawing.Size(47, 23);
            this.lb_june.TabIndex = 55;
            this.lb_june.Text = "Text";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label39);
            this.panel17.Controls.Add(this.lb_february);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(3, 110);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(215, 101);
            this.panel17.TabIndex = 3;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(80, 26);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(62, 17);
            this.label39.TabIndex = 54;
            this.label39.Text = "February";
            // 
            // lb_february
            // 
            this.lb_february.AutoSize = true;
            this.lb_february.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_february.ForeColor = System.Drawing.Color.Green;
            this.lb_february.Location = new System.Drawing.Point(83, 49);
            this.lb_february.Name = "lb_february";
            this.lb_february.Size = new System.Drawing.Size(47, 23);
            this.lb_february.TabIndex = 55;
            this.lb_february.Text = "Text";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label30);
            this.panel16.Controls.Add(this.lb_september);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(445, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(216, 101);
            this.panel16.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(81, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(78, 17);
            this.label30.TabIndex = 54;
            this.label30.Text = "September";
            // 
            // lb_september
            // 
            this.lb_september.AutoSize = true;
            this.lb_september.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_september.ForeColor = System.Drawing.Color.Green;
            this.lb_september.Location = new System.Drawing.Point(84, 49);
            this.lb_september.Name = "lb_september";
            this.lb_september.Size = new System.Drawing.Size(47, 23);
            this.lb_september.TabIndex = 55;
            this.lb_september.Text = "Text";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label24);
            this.panel15.Controls.Add(this.lb_may);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(224, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(215, 101);
            this.panel15.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(80, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 17);
            this.label24.TabIndex = 54;
            this.label24.Text = "May";
            // 
            // lb_may
            // 
            this.lb_may.AutoSize = true;
            this.lb_may.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_may.ForeColor = System.Drawing.Color.Green;
            this.lb_may.Location = new System.Drawing.Point(83, 49);
            this.lb_may.Name = "lb_may";
            this.lb_may.Size = new System.Drawing.Size(47, 23);
            this.lb_may.TabIndex = 55;
            this.lb_may.Text = "Text";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label53);
            this.panel14.Controls.Add(this.lb_january);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(215, 101);
            this.panel14.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(80, 26);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(58, 17);
            this.label53.TabIndex = 54;
            this.label53.Text = "January";
            // 
            // lb_january
            // 
            this.lb_january.AutoSize = true;
            this.lb_january.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_january.ForeColor = System.Drawing.Color.Green;
            this.lb_january.Location = new System.Drawing.Point(83, 49);
            this.lb_january.Name = "lb_january";
            this.lb_january.Size = new System.Drawing.Size(47, 23);
            this.lb_january.TabIndex = 55;
            this.lb_january.Text = "Text";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.cbox_spp_cek);
            this.panel13.Location = new System.Drawing.Point(389, 232);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(137, 36);
            this.panel13.TabIndex = 59;
            // 
            // cbox_spp_cek
            // 
            this.cbox_spp_cek.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp_cek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp_cek.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp_cek.FormattingEnabled = true;
            this.cbox_spp_cek.IntegralHeight = false;
            this.cbox_spp_cek.Location = new System.Drawing.Point(4, 4);
            this.cbox_spp_cek.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp_cek.Name = "cbox_spp_cek";
            this.cbox_spp_cek.Size = new System.Drawing.Size(127, 25);
            this.cbox_spp_cek.TabIndex = 43;
            this.cbox_spp_cek.SelectedIndexChanged += new System.EventHandler(this.cbox_spp_cek_SelectedIndexChanged);
            // 
            // rb_tahun_lainnya_cek
            // 
            this.rb_tahun_lainnya_cek.AutoSize = true;
            this.rb_tahun_lainnya_cek.Location = new System.Drawing.Point(244, 243);
            this.rb_tahun_lainnya_cek.Name = "rb_tahun_lainnya_cek";
            this.rb_tahun_lainnya_cek.Size = new System.Drawing.Size(124, 17);
            this.rb_tahun_lainnya_cek.TabIndex = 58;
            this.rb_tahun_lainnya_cek.TabStop = true;
            this.rb_tahun_lainnya_cek.Text = "Another fee category";
            this.rb_tahun_lainnya_cek.UseVisualStyleBackColor = true;
            this.rb_tahun_lainnya_cek.CheckedChanged += new System.EventHandler(this.rb_tahun_lainnya_cek_CheckedChanged);
            // 
            // rb_tahun_ini_cek
            // 
            this.rb_tahun_ini_cek.AutoSize = true;
            this.rb_tahun_ini_cek.Location = new System.Drawing.Point(117, 243);
            this.rb_tahun_ini_cek.Name = "rb_tahun_ini_cek";
            this.rb_tahun_ini_cek.Size = new System.Drawing.Size(121, 17);
            this.rb_tahun_ini_cek.TabIndex = 57;
            this.rb_tahun_ini_cek.TabStop = true;
            this.rb_tahun_ini_cek.Text = "Current fee category";
            this.rb_tahun_ini_cek.UseVisualStyleBackColor = true;
            this.rb_tahun_ini_cek.CheckedChanged += new System.EventHandler(this.rb_tahun_ini_cek_CheckedChanged);
            // 
            // lb_nominal_cek
            // 
            this.lb_nominal_cek.AutoSize = true;
            this.lb_nominal_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_nominal_cek.Location = new System.Drawing.Point(380, 183);
            this.lb_nominal_cek.Name = "lb_nominal_cek";
            this.lb_nominal_cek.Size = new System.Drawing.Size(52, 25);
            this.lb_nominal_cek.TabIndex = 51;
            this.lb_nominal_cek.Text = "Text";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(377, 159);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(87, 17);
            this.label29.TabIndex = 50;
            this.label29.Text = "Fee nominal";
            // 
            // lb_nama_cek
            // 
            this.lb_nama_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_nama_cek.Location = new System.Drawing.Point(41, 109);
            this.lb_nama_cek.Name = "lb_nama_cek";
            this.lb_nama_cek.Size = new System.Drawing.Size(454, 25);
            this.lb_nama_cek.TabIndex = 41;
            this.lb_nama_cek.Text = "Text";
            // 
            // lb_kategori_cek
            // 
            this.lb_kategori_cek.AutoSize = true;
            this.lb_kategori_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori_cek.Location = new System.Drawing.Point(41, 182);
            this.lb_kategori_cek.Name = "lb_kategori_cek";
            this.lb_kategori_cek.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori_cek.TabIndex = 40;
            this.lb_kategori_cek.Text = "Text";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(38, 85);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 17);
            this.label32.TabIndex = 37;
            this.label32.Text = "Name";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(38, 159);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(92, 17);
            this.label33.TabIndex = 33;
            this.label33.Text = "Fee category";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.FlatAppearance.BorderSize = 2;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.Green;
            this.button19.Location = new System.Drawing.Point(16, 729);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(126, 37);
            this.button19.TabIndex = 31;
            this.button19.Text = "Back";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(15, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(311, 41);
            this.label34.TabIndex = 23;
            this.label34.Text = "Payment History";
            // 
            // FormRiwayat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1654, 787);
            this.Controls.Add(this.panel_detail2);
            this.Controls.Add(this.panel_cek);
            this.Controls.Add(this.panel_detail);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRiwayat";
            this.Text = "FormRiwayat";
            this.Load += new System.EventHandler(this.FormRiwayat_Load);
            this.panel_detail.ResumeLayout(false);
            this.panel_detail.PerformLayout();
            this.panel_not_found.ResumeLayout(false);
            this.panel_not_found.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaraan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).EndInit();
            this.panel_detail2.ResumeLayout(false);
            this.panel_detail2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaran_detail2)).EndInit();
            this.panel_cek.ResumeLayout(false);
            this.panel_cek.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_detail;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.CheckBox check_spp_detail;
        private System.Windows.Forms.ComboBox cbox_spp_detail;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.CheckBox check_bulan_detail;
        private System.Windows.Forms.ComboBox cbox_bulan_detail;
        private System.Windows.Forms.CheckBox check_showall_detail;
        private System.Windows.Forms.DataGridView dgv_history_pembayaraan;
        private System.Windows.Forms.PictureBox pb_foto_detail;
        private System.Windows.Forms.Label lb_nis;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_kelas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel_detail2;
        private System.Windows.Forms.Label lb_tanggungan_detail2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lb_status_detail2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgv_history_pembayaran_detail2;
        private System.Windows.Forms.Label lb_kategori_detail2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_nama_detail2;
        private System.Windows.Forms.Label lb_bulan_detail2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel_not_found;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel_cek;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label lb_december;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lb_august;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label lb_april;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lb_november;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lb_july;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lb_march;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lb_october;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lb_june;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lb_february;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lb_september;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lb_may;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label lb_january;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.ComboBox cbox_spp_cek;
        private System.Windows.Forms.RadioButton rb_tahun_lainnya_cek;
        private System.Windows.Forms.RadioButton rb_tahun_ini_cek;
        private System.Windows.Forms.Label lb_nominal_cek;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lb_nama_cek;
        private System.Windows.Forms.Label lb_kategori_cek;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label34;
    }
}
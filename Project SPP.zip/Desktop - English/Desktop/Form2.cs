﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class Form2 : Form
    {
        Helper helper = new Helper();

        public Form2()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (helper.NumberValidation(tbox_nis, "NIS") == 0 || helper.NumberValidation(tbox_nisn, "NISN") == 0)
            {
                return;
            }

            DataTable dt = helper.GetTable($"Select * from tbl_siswa where nisn={tbox_nisn.Text} and status = 1");
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                if (tbox_nis.Text == row["nis"].ToString())
                {
                    Session_login.id = int.Parse(row["id"].ToString());
                    Session_login.nama = row["nama"].ToString();
                    Session_login.role = "student";

                    if (string.IsNullOrEmpty(row["foto"].ToString()))
                    {
                        Session_login.foto = null;
                    }
                    else
                    {
                        Session_login.foto = (byte[])row["foto"];
                    }
                    FormMain obj = new FormMain();
                    obj.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect NIS.");
                }
            }
            else
            {
                MessageBox.Show("NISN not found.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormPetugas : Form
    {
        Helper helper = new Helper();
        int id = 0;

        public FormPetugas()
        {
            InitializeComponent();
        }

        private void FormPetugas_Load(object sender, EventArgs e)
        {
            panel2.Location = new Point(0, 0);
            panel2.Hide();

            panel_detail.Location = new Point(0, 0);
            panel_detail.Hide();

            LoadDgv();
            ComboBoxSet();
        }

        private void ComboBoxSet()
        {
            cbox_role.DataSource = helper.GetTable("Select * from tbl_role");
            cbox_role.ValueMember= "id";
            cbox_role.DisplayMember= "nama";
        }

        private void LoadDgv()
        {
            dgv_petugas.DataSource = helper.GetTable("Select tbl_petugas.id as ID, tbl_petugas.nama as Name, tbl_role.nama as Role, created_at as Created from tbl_petugas inner join tbl_role on tbl_role.id = tbl_petugas.id_role");
            if (dgv_petugas.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Show();

            id = 0;
            tbox_nama.Text = "";
            tbox_password.Text = "";
            tbox_email.Text = "";
            cbox_role.SelectedIndex = 0;
            pb_foto.Image = null;

            button7.Text = "Create";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (helper.EmailValidation(tbox_email) == 0 || helper.NameValidation(tbox_nama, "Nama") == 0 || helper.LengthMin(tbox_password, 4, "Password") == 0 || helper.LengthMax(tbox_nama,50,"Nama") == 0 || helper.LengthMin(tbox_nama, 3, "Nama") == 0)
            {
                return;
            }



            if(id == 0)
            {
                string query = $"Insert into tbl_petugas values(" +
                    $"'{cbox_role.SelectedValue}'," +
                    $"'{tbox_email.Text}'," +
                    $"'{tbox_nama.Text}'," +
                    $"'{helper.sha256(tbox_password.Text)}'," +
                    $"1," +
                    $"@datenow," +
                    $"@datenow," +
                    $"@img)";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);

                if (pb_foto.Image == null)
                {
                    SqlParameter img = new SqlParameter("@img", SqlDbType.Image);
                    img.Value = DBNull.Value;
                    cmd.Parameters.Add(img);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@img", helper.PictureBoxToByte(pb_foto));
                }

                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data created successfully.");
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
            else
            {
                string query = $"Update tbl_petugas set " +
                   $"id_role='{cbox_role.SelectedValue}'," +
                   $"email='{tbox_email.Text}'," +
                   $"nama='{tbox_nama.Text}'," +
                   $"password='{helper.sha256(tbox_password.Text)}'," +
                   $"last_updated=@datenow," +
                   $"foto=@img" +
                   $" where id = {id}";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);

                if (pb_foto.Image == null)
                {
                    SqlParameter img = new SqlParameter("@img", SqlDbType.Image);
                    img.Value = DBNull.Value;
                    cmd.Parameters.Add(img);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@img", helper.PictureBoxToByte(pb_foto));
                }

                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data changed successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            panel1.Hide();
            panel2.Show();

            id = int.Parse(dgv_petugas.Rows[dgv_petugas.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select * from tbl_petugas where id = {id}");
            DataRow row = dt.Rows[0];
            tbox_nama.Text = row["nama"].ToString();
            tbox_email.Text = row["email"].ToString();
            tbox_password.Text = "";
            cbox_role.SelectedValue = row["id_role"].ToString();

            if(string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto.Image = null;
            }
            else
            {
                pb_foto.Image = helper.ByteToImage((byte[]) row["foto"]);
            }

            button7.Text = "Edit";
        }

        private void tbox_search_TextChanged(object sender, EventArgs e)
        {
            searchDgv();
        }

        private void searchDgv()
        {
            dgv_petugas.DataSource = helper.GetTable($"Select tbl_petugas.id as ID, tbl_petugas.nama as Nama, tbl_role.nama as Role, created_at as Created from tbl_petugas inner join tbl_role on tbl_role.id = tbl_petugas.id_role where tbl_petugas.id like '%{tbox_search.Text}%' or tbl_petugas.nama like '%{tbox_search.Text}%' or tbl_role.nama like '%{tbox_search.Text}%' or created_at like '%{tbox_search.Text}%' or email like '%{tbox_search.Text}%'");
            if (dgv_petugas.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel_detail.Hide();
            panel1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            panel1.Hide();
            panel_detail.Show();

            id = int.Parse(dgv_petugas.Rows[dgv_petugas.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select tbl_petugas.*, tbl_role.nama as nama_role from tbl_petugas inner join tbl_role on tbl_role.id = tbl_petugas.id_role where tbl_petugas.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama.Text = row["nama"].ToString();
            lb_email.Text = row["email"].ToString();
            lb_created.Text = row["created_at"].ToString();
            lb_role.Text = row["nama_role"].ToString();
            if (int.Parse(row["status"].ToString()) == 0)
            {
                lb_status.Text = "Non-active";
            }
            if (int.Parse(row["status"].ToString()) == 1)
            {
                lb_status.Text = "Active";
            }
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto_detail.Image = null;
            }
            else
            {
                pb_foto_detail.Image = helper.ByteToImage((byte[])row["foto"]);
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Enable This Data?", "Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_petugas.Rows[dgv_petugas.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_petugas set status=1 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Disable This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_petugas.Rows[dgv_petugas.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_petugas set status=0 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Delete This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_petugas.Rows[dgv_petugas.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Delete from tbl_petugas where id = {id}");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Data is still in use.");
                    return;
                }
                MessageBox.Show("Data successfully deleted");
                LoadDgv();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dgv_petugas.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            DataTable dt = helper.GetTable("Select tbl_petugas.id as ID, tbl_petugas.nama as Nama, tbl_role.nama as Role, created_at as Created from tbl_petugas inner join tbl_role on tbl_role.id = tbl_petugas.id_role");
            helper.ExportExcel(dt);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            helper.OpenImage(pb_foto);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            pb_foto.Image = null;
        }
    }
}

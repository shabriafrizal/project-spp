﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormSiswa : Form
    {
        int id, nis, nisn = 0;
        Helper helper = new Helper();
        public FormSiswa()
        {
            InitializeComponent();
        }
        private void FormSiswa_Load(object sender, EventArgs e)
        {
            panel2.Location = new Point(0, 0);
            panel2.Hide();

            panel_detail.Location = new Point(0, 0);
            panel_detail.Hide();

            CheckedShowall();
            LoadDgv();
            ComboBoxSet();
        }

        private void CheckedShowall()
        {
            check_showall.Checked = true;
            if(check_showall.Checked)
            {
                LoadDgv();
            }
        }

        private void LoadDgv()
        {
            dgv_siswa.DataSource = helper.GetTable("select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas");
            if (dgv_siswa.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }

        private void ComboBoxSet()
        {
            cbox_kelas.DataSource = helper.GetTable("select * from tbl_kelas where status = 1");
            cbox_kelas.ValueMember= "id";
            cbox_kelas.DisplayMember= "nama";
            cbox_search.DataSource = helper.GetTable("select * from tbl_kelas where status = 1");
            cbox_search.ValueMember = "id";
            cbox_search.DisplayMember = "nama";
            cbox_spp.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp.ValueMember= "id";
            cbox_spp.DisplayMember= "keterangan";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Show();

            id = 0;
            nis = 0;
            nisn = 0;
            tbox_nisn.Text = "";
            tbox_nis.Text = "";
            tbox_nama.Text = "";
            tbox_telp.Text = "";
            tbox_alamat.Text = "";
            dtpick_lahir.Value = DateTime.Now;
            pb_foto.Image = null;
            rb_laki.Checked = false;
            rb_perempuan.Checked = false;

            button7.Text = "Create";
        }

        private void cbox_search_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (check_showall.Checked)
            {
                LoadDgv();
            }
            else
            {
                dgv_siswa.DataSource = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue}");
                if (dgv_siswa.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void check_showall_CheckedChanged(object sender, EventArgs e)
        {
            if (check_showall.Checked)
            {
                LoadDgv();
            }
            else
            {
                dgv_siswa.DataSource = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue}");
                if (dgv_siswa.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }

            panel1.Hide();
            panel2.Show();

            id = int.Parse(dgv_siswa.Rows[dgv_siswa.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select * from tbl_siswa where id = {id}");
            DataRow row = dt.Rows[0];
            nis = int.Parse(row["nis"].ToString());
            nisn = int.Parse(row["nisn"].ToString());

            tbox_nisn.Text = row["nisn"].ToString();
            tbox_nis.Text = row["nis"].ToString();
            tbox_nama.Text = row["nama"].ToString();
            tbox_telp.Text = long.Parse(row["no_telp"].ToString()).ToString();
            tbox_alamat.Text = row["alamat"].ToString();
            cbox_kelas.SelectedValue = row["id_kelas"].ToString();
            cbox_spp.SelectedValue = row["id_spp"].ToString();
            dtpick_lahir.Value = DateTime.Parse(row["tanggal_lahir"].ToString());
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto.Image = null;
            }
            else
            {
                pb_foto.Image = helper.ByteToImage((byte[])row["foto"]);
            }
            if (row["jenis_kelamin"].ToString() == "Woman")
            {
                rb_perempuan.Checked = true;
            }
            if (row["jenis_kelamin"].ToString() == "Man")
            {
                rb_laki.Checked = true;
            }

            button7.Text = "Change";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }

            panel1.Hide();
            panel_detail.Show();

            id = int.Parse(dgv_siswa.Rows[dgv_siswa.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"select tbl_siswa.*,tbl_spp.nominal as Nominal, tbl_spp.keterangan as spp, tbl_kelas.nama as Nama_kelas from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama.Text = row["nama"].ToString();
            lb_nisn.Text = row["nisn"].ToString();
            lb_nis.Text = row["nis"].ToString();
            lb_alamat.Text = row["alamat"].ToString();
            lb_telp.Text = row["no_telp"].ToString();
            lb_lahir.Text = row["tanggal_lahir"].ToString();
            lb_kelamin.Text = row["jenis_kelamin"].ToString();
            lb_lahir.Text = row["tanggal_lahir"].ToString();
            lb_nominal.Text = row["nominal"].ToString();
            lb_spp.Text = row["spp"].ToString();
            lb_kelas.Text = row["nama_kelas"].ToString();
            lb_created.Text = row["created_at"].ToString();
            if (int.Parse(row["status"].ToString()) == 0)
            {
                lb_status.Text = "Non-active";
            }
            if (int.Parse(row["status"].ToString()) == 1)
            {
                lb_status.Text = "Active";
            }
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto_detail.Image = null;
            }
            else
            {
                pb_foto_detail.Image = helper.ByteToImage((byte[])row["foto"]);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel_detail.Hide();
            panel1.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            helper.OpenImage(pb_foto);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            pb_foto.Image = null;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(helper.NumberValidation(tbox_nis, "NIS") == 0 || helper.NumberValidation(tbox_nisn, "NISN") == 0 || helper.NumberValidation(tbox_telp, "No Telpon") == 0 || helper.NameValidation(tbox_nama, "Nama") == 0 || helper.LengthMin(tbox_nama, 3,"Nama") == 0 || helper.LengthMax(tbox_nama, 100, "Nama") == 0 || helper.LengthMax(tbox_telp, 10, "No Telp") == 0)
            {
                return;
            }

            if(cbox_kelas.Text == "" || cbox_kelas.Text == "")
            {
                MessageBox.Show("Data Insufficient.");
                return;
            }

            if(rb_perempuan.Checked == false && rb_laki.Checked == false)
            {
                MessageBox.Show("Data Insufficient.");
                return;
            }

            if (id == 0)
            {
                DataTable dt_nis = helper.GetTable($"select * from tbl_siswa where nis='{tbox_nis.Text}'");
                if(dt_nis.Rows.Count > 0)
                {
                    MessageBox.Show("NIS Has been used.");
                    return;
                }

                DataTable dt_nisn = helper.GetTable($"select * from tbl_siswa where nisn='{tbox_nisn.Text}'");
                if (dt_nisn.Rows.Count > 0)
                {
                    MessageBox.Show("NISN Has been used.");
                    return;
                }

                string jenis_kel = "Woman";
                if(rb_laki.Checked)
                {
                    jenis_kel = "Man";
                }
                if (rb_perempuan.Checked)
                {
                    jenis_kel = "Woman";
                }

                string query = $"Insert into tbl_siswa values(" +
                    $"{tbox_nisn.Text}," +
                    $"'{tbox_nama.Text}'," +
                    $"'{cbox_kelas.SelectedValue}'," +
                    $"'{cbox_spp.SelectedValue}'," +
                    $"'{tbox_alamat.Text}'," +
                    $"'{tbox_telp.Text}'," +
                    $"1," +
                    $"@datenow," +
                    $"@datenow," +
                    $"@lahir," +
                    $"@img," +
                    $"'{jenis_kel}'," +
                    $"{tbox_nis.Text})";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);
                cmd.Parameters.AddWithValue("@lahir", dtpick_lahir.Value);
                if(pb_foto.Image == null)
                {
                    SqlParameter img = new SqlParameter("@img", SqlDbType.Image);
                    img.Value = DBNull.Value;
                    cmd.Parameters.Add(img);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@img", helper.PictureBoxToByte(pb_foto));
                }
                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data created successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
            else
            {
                DataTable dt_nis = helper.GetTable($"select * from tbl_siswa where nis='{tbox_nis.Text}' and nis != {nis}");
                if (dt_nis.Rows.Count > 0)
                {
                    MessageBox.Show("NIS Has been used.");
                    return;
                }

                DataTable dt_nisn = helper.GetTable($"select * from tbl_siswa where nisn='{tbox_nisn.Text}' and nisn != {nisn}");
                if (dt_nisn.Rows.Count > 0)
                {
                    MessageBox.Show("NISN Has been used.");
                    return;
                }

                string jenis_kel = "Woman";
                if (rb_laki.Checked)
                {
                    jenis_kel = "Man";
                }
                if (rb_perempuan.Checked)
                {
                    jenis_kel = "Woman";
                }
                string query = $"update tbl_siswa set " +
                    $"nisn='{tbox_nisn.Text}'," +
                    $"nama='{tbox_nama.Text}'," +
                    $"id_kelas='{cbox_kelas.SelectedValue}'," +
                    $"id_spp='{cbox_spp.SelectedValue}'," +
                    $"alamat='{tbox_alamat.Text}'," +
                    $"no_telp='{tbox_telp.Text}'," +
                    $"last_updated=@datenow," +
                    $"tanggal_lahir=@lahir," +
                    $"foto=@img," +
                    $"jenis_kelamin='{jenis_kel}'," +
                    $"nis='{tbox_nis.Text}' " +
                    $" where id = {id}";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);
                cmd.Parameters.AddWithValue("@lahir", dtpick_lahir.Value);
                if (pb_foto.Image == null)
                {
                    SqlParameter img = new SqlParameter("@img", SqlDbType.Image);
                    img.Value = DBNull.Value;
                    cmd.Parameters.Add(img);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@img", helper.PictureBoxToByte(pb_foto));
                }
                try
                {
                    var res = helper.InsertCmd(cmd);
                    MessageBox.Show("Data Changed successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                panel1.Show();
                panel2.Hide();
                LoadDgv();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Delete This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_siswa.Rows[dgv_siswa.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Delete from tbl_siswa where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data is still in use.");
                    return;
                }
                MessageBox.Show("Data successfully deleted");
                LoadDgv();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data None.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Enable This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_siswa.Rows[dgv_siswa.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_siswa set status=1 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data Tidak ada.");
                return;
            }
            
            if (MessageBox.Show("Are You Sure To Disable This Data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                id = int.Parse(dgv_siswa.Rows[dgv_siswa.CurrentCell.RowIndex].Cells[0].Value.ToString());
                try
                {
                    var res = helper.Insert($"Update tbl_siswa set status=0 where id = {id}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                MessageBox.Show("Data changed successfully");
                LoadDgv();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dgv_siswa.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            if (check_showall.Checked == true)
            {
                DataTable dt = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue}");
                helper.ExportExcel(dt);
            }
            else
            {
                DataTable dt = helper.GetTable("select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas");
                helper.ExportExcel(dt);
            }
            
        }
    }
}

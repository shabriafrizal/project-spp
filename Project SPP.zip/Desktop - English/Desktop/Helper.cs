﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    internal class Helper
    {
        public SqlConnection connection;

        public Helper()
        {
            string strCon = @"Data Source=.\sqlexpress;initial catalog=DB_SPP_ENG;integrated security=true";
            connection = new SqlConnection(strCon);
        }

        public void OpenConnection()
        {
            if(connection.State != ConnectionState.Open)
            {
                connection.Open();
            }
        }

        public void CloseConnection()
        {
            if (connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        public DataTable GetTable(string query)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = connection;
            OpenConnection();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            CloseConnection();
            return dt;
        }

        public DataTable GetTableCmd(SqlCommand cmd)
        {
            DataTable dt = new DataTable();
            cmd.Connection = connection;
            OpenConnection();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            CloseConnection();
            return dt;
        }

        public int Insert(string query)
        {
            SqlCommand cmd = new SqlCommand(query);
            cmd.Connection = connection;
            OpenConnection();
            var res = cmd.ExecuteNonQuery();
            CloseConnection();
            return res;
        }

        public int InsertCmd(SqlCommand cmd)
        {
            cmd.Connection = connection;
            OpenConnection();
            var res = cmd.ExecuteNonQuery();
            CloseConnection();
            return res;
        }

        public byte[] PictureBoxToByte(PictureBox pictureBox) 
        {
            MemoryStream ms = new MemoryStream();
            pictureBox.Image.Save(ms, pictureBox.Image.RawFormat);
            return ms.ToArray();
        }

        public Image ByteToImage(byte[] data)
        {
            MemoryStream ms = new MemoryStream(data);
            return Image.FromStream(ms);
        }

        public void OpenForm(Form form, Panel panel)
        {
            form.TopLevel = false;
            panel.Controls.Add(form);
            panel.Tag = form;
            form.BringToFront();
            form.Show();
        }

        public void OpenImage(PictureBox pictureBox)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images|*.jpg;*.jpeg;*.png";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image = new Bitmap(ofd.FileName);
            }
        }

        public string sha256(string text)
        {
            byte[] bytes= Encoding.UTF8.GetBytes(text);
            bytes= SHA256.Create().ComputeHash(bytes);
            return Convert.ToBase64String(bytes);
        }

        public void ExportExcel(DataTable dt)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel|*.xlsx";
            if(sfd.ShowDialog() == DialogResult.OK)
            {
                XLWorkbook workbook = new XLWorkbook();
                workbook.AddWorksheet(dt, "1");
                workbook.SaveAs(sfd.FileName);
                MessageBox.Show("Saved Data");
            }
        }

        public int EmailValidation(TextBox textBox)
        {
            try
            {
                new MailAddress(textBox.Text);
                return 1;
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Blank Email.");
                return 0;
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Email.");
                return 0;
            }
        }

        public int NameValidation(TextBox textBox, string tulisan)
        {
            if(textBox.Text.Length > 0)
            {
                if (Regex.IsMatch(textBox.Text, @"^[a-zA-Z ]+$"))
                {
                    return 1;
                }
                else
                {
                    MessageBox.Show("There are Forbidden Characters for " + tulisan);
                    return 0;
                }
            }
            else
            {
                MessageBox.Show("Data "+ tulisan + " is blank.");
                return 0;
            }
        }

        public int NumberValidation(TextBox textBox, string tulisan)
        {
            if (textBox.Text.Length > 0)
            {
                if (Regex.IsMatch(textBox.Text, @"^[0-9]+$"))
                {
                    return 1;
                }
                else
                {
                    MessageBox.Show("There are Forbidden Characters for " + tulisan);
                    return 0;
                }
            }
            else
            {
                MessageBox.Show("Data " + tulisan + " is blank.");
                return 0;
            }
                
        }

        public int LengthMin(TextBox textBox, int length, string tulisan)
        {
            if(textBox.Text.Length < length)
            {
                MessageBox.Show("Length "+ tulisan +" Minimum is "+ length);
                return 0;
            }
            else
            {
                return 1;
            }
        }

        public int LengthMax(TextBox textBox, int length, string tulisan)
        {
            if (textBox.Text.Length > length)
            {
                MessageBox.Show("Length " + tulisan + " Maximum is " + length);
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }
}

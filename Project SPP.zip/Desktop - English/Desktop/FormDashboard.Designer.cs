﻿
namespace Desktop
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgv_riwayat = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lb_total_pembayaran = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lb_total_spp = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb_total_kelas = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_total_siswa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_riwayat)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.dgv_riwayat);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(712, 787);
            this.panel3.TabIndex = 30;
            // 
            // dgv_riwayat
            // 
            this.dgv_riwayat.AllowUserToAddRows = false;
            this.dgv_riwayat.AllowUserToDeleteRows = false;
            this.dgv_riwayat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_riwayat.BackgroundColor = System.Drawing.Color.White;
            this.dgv_riwayat.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_riwayat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_riwayat.ColumnHeadersHeight = 60;
            this.dgv_riwayat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_riwayat.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_riwayat.EnableHeadersVisualStyles = false;
            this.dgv_riwayat.GridColor = System.Drawing.Color.Black;
            this.dgv_riwayat.Location = new System.Drawing.Point(35, 297);
            this.dgv_riwayat.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_riwayat.MultiSelect = false;
            this.dgv_riwayat.Name = "dgv_riwayat";
            this.dgv_riwayat.ReadOnly = true;
            this.dgv_riwayat.RowHeadersVisible = false;
            this.dgv_riwayat.RowHeadersWidth = 51;
            this.dgv_riwayat.RowTemplate.Height = 50;
            this.dgv_riwayat.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_riwayat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_riwayat.Size = new System.Drawing.Size(635, 199);
            this.dgv_riwayat.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(43, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(256, 25);
            this.label6.TabIndex = 33;
            this.label6.Text = "Today\'s Payment History";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(43, 518);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(308, 25);
            this.label7.TabIndex = 31;
            this.label7.Text = "Number of Students Per Class";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.chart2);
            this.panel7.Location = new System.Drawing.Point(35, 555);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(635, 195);
            this.panel7.TabIndex = 32;
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(3, 3);
            this.chart2.Name = "chart2";
            this.chart2.Size = new System.Drawing.Size(612, 189);
            this.chart2.TabIndex = 28;
            this.chart2.Text = "chart2";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.lb_total_pembayaran);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(503, 83);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(167, 153);
            this.panel5.TabIndex = 27;
            // 
            // lb_total_pembayaran
            // 
            this.lb_total_pembayaran.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total_pembayaran.ForeColor = System.Drawing.Color.White;
            this.lb_total_pembayaran.Location = new System.Drawing.Point(23, 74);
            this.lb_total_pembayaran.Name = "lb_total_pembayaran";
            this.lb_total_pembayaran.Size = new System.Drawing.Size(122, 55);
            this.lb_total_pembayaran.TabIndex = 4;
            this.lb_total_pembayaran.Text = "110";
            this.lb_total_pembayaran.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(28, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 50);
            this.label5.TabIndex = 3;
            this.label5.Text = "Today\'s \r\nPayment";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Green;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lb_total_spp);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(347, 83);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(150, 153);
            this.panel4.TabIndex = 26;
            // 
            // lb_total_spp
            // 
            this.lb_total_spp.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total_spp.ForeColor = System.Drawing.Color.White;
            this.lb_total_spp.Location = new System.Drawing.Point(15, 61);
            this.lb_total_spp.Name = "lb_total_spp";
            this.lb_total_spp.Size = new System.Drawing.Size(122, 80);
            this.lb_total_spp.TabIndex = 3;
            this.lb_total_spp.Text = "110";
            this.lb_total_spp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(16, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 50);
            this.label4.TabIndex = 2;
            this.label4.Text = "Total Fee\'s \r\ncategory\r\n";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Green;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lb_total_kelas);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(191, 83);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(150, 153);
            this.panel2.TabIndex = 25;
            // 
            // lb_total_kelas
            // 
            this.lb_total_kelas.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total_kelas.ForeColor = System.Drawing.Color.White;
            this.lb_total_kelas.Location = new System.Drawing.Point(11, 61);
            this.lb_total_kelas.Name = "lb_total_kelas";
            this.lb_total_kelas.Size = new System.Drawing.Size(122, 80);
            this.lb_total_kelas.TabIndex = 2;
            this.lb_total_kelas.Text = "110";
            this.lb_total_kelas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(15, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Total Class";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lb_total_siswa);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(35, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 153);
            this.panel1.TabIndex = 24;
            // 
            // lb_total_siswa
            // 
            this.lb_total_siswa.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total_siswa.ForeColor = System.Drawing.Color.White;
            this.lb_total_siswa.Location = new System.Drawing.Point(14, 61);
            this.lb_total_siswa.Name = "lb_total_siswa";
            this.lb_total_siswa.Size = new System.Drawing.Size(122, 80);
            this.lb_total_siswa.TabIndex = 1;
            this.lb_total_siswa.Text = "110";
            this.lb_total_siswa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(28, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 50);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total\r\nStudents";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 41);
            this.label3.TabIndex = 23;
            this.label3.Text = "Dashboard";
            // 
            // FormDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(789, 787);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormDashboard";
            this.Text = "FormDashboard";
            this.Load += new System.EventHandler(this.FormDashboard_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_riwayat)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_total_siswa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_total_pembayaran;
        private System.Windows.Forms.Label lb_total_spp;
        private System.Windows.Forms.Label lb_total_kelas;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgv_riwayat;
    }
}
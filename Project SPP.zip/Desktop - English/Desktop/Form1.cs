﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class Form1 : Form
    {
        Helper helper = new Helper();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(helper.EmailValidation(textBox1) == 0 || helper.LengthMin(textBox2, 4, "Password") == 0)
            {
                return;
            }

            DataTable dt = helper.GetTable($"Select tbl_petugas.*, tbl_role.nama as nama_role from tbl_petugas inner join tbl_role on tbl_role.id = tbl_petugas.id_role where email = '{textBox1.Text}' and status = 1");
            if(dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                if (helper.sha256(textBox2.Text) == row["password"].ToString())
                {
                    Session_login.id = int.Parse(row["id"].ToString());
                    Session_login.nama = row["nama"].ToString();
                    Session_login.role = row["nama_role"].ToString();

                    if (string.IsNullOrEmpty(row["foto"].ToString()))
                    {
                        Session_login.foto = null;
                    }
                    else
                    {
                        Session_login.foto = (byte[])row["foto"];
                    }
                    FormMain obj = new FormMain();
                    obj.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect password.");
                }
            }
            else
            {
                MessageBox.Show("User not found.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            obj.Show();
            this.Hide();
        }
    }
}

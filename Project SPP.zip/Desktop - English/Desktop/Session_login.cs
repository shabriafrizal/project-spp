﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desktop
{
    internal class Session_login
    {
        public static int id { get; set; }
        public static string nama { get; set; }
        public static string role { get; set; }
        public static byte[] foto { get; set; }
    }
}

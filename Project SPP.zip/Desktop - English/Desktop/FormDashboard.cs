﻿using DocumentFormat.OpenXml.Office.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormDashboard : Form
    {
        Helper helper = new Helper();
        public FormDashboard()
        {
            InitializeComponent();
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            TotalSiswa();
            TotalKelas();
            TotalSpp();
            TotalPembayaran();
            DgvRiwayat();
            ChartNominalPerkelas();
        }

        private void DgvRiwayat()
        {
            SqlCommand cmd = new SqlCommand("Select tbl_siswa.nama as Student, tbl_kelas.nama as Class, tanggal_pembayaran as Date, jumlah_bayar as Amount from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp inner join tbl_siswa on tbl_siswa.id = tbl_pembayaran.id_siswa inner join tbl_petugas on tbl_petugas.id = tbl_pembayaran.id_petugas inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tanggal_pembayaran between @datestart and @dateend order by tanggal_pembayaran desc");
            cmd.Parameters.AddWithValue("@datestart", DateTime.Now.AddDays(-1));
            cmd.Parameters.AddWithValue("@dateend", DateTime.Now.AddDays(0));
            dgv_riwayat.DataSource = helper.GetTableCmd(cmd);
        }

        private void ChartNominalPerkelas()
        {
            //DataTable dt = helper.GetTable("Select * from tbl_kelas");
            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    DataRow row = dt.Rows[i];
            //    chart1.Series.Add(row["nama"].ToString());

            //    DataTable dt1 = helper.GetTable($"Select sum(jumlah_bayar) as Bayar, bulan_dibayar as Bulan from tbl_pembayaran inner join tbl_siswa on tbl_siswa.id = tbl_pembayaran.id_siswa where tbl_siswa.id_kelas = {row["id"]} group by bulan_dibayar");
            //    for (int j = 0; j < dt1.Rows.Count; j++)
            //    {
            //        DataRow row1 = dt1.Rows[j];
            //        chart1.Series.FindByName(row["nama"].ToString()).Points.AddXY(row1["Bulan"].ToString(), row1["Bayar"].ToString());
            //    }
            //}

            DataTable dt2 = helper.GetTable("Select count(*) as count, tbl_kelas.nama as Nama from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas group by tbl_kelas.nama");
            chart2.DataSource = dt2;
            chart2.Series.Add("The number of students");
            chart2.Series.First().YValueMembers = "count";
            chart2.Series.First().XValueMember = "nama";

        }

        private void TotalPembayaran()
        {
            SqlCommand cmd = new SqlCommand("Select count(*) as Count from tbl_pembayaran where tanggal_pembayaran between @datestart and @dateend");
            cmd.Parameters.AddWithValue("@datestart", DateTime.Now.AddDays(-1));
            cmd.Parameters.AddWithValue("@dateend", DateTime.Now.AddDays(0));
            DataRow row = helper.GetTableCmd(cmd).Rows[0];
            lb_total_pembayaran.Text = row["Count"].ToString();
        }

        private void TotalSpp()
        {
            DataRow row = helper.GetTable("Select count(*) as Count from tbl_spp").Rows[0];
            lb_total_spp.Text = row["Count"].ToString();
        }

        private void TotalSiswa()
        {
            DataRow row = helper.GetTable("Select count(*) as Count from tbl_siswa").Rows[0];
            lb_total_siswa.Text = row["Count"].ToString();
        }

        private void TotalKelas()
        {
            DataRow row = helper.GetTable("Select count(*) as Count from tbl_kelas").Rows[0];
            lb_total_kelas.Text = row["Count"].ToString();
        }
    }
}

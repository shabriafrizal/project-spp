﻿using DocumentFormat.OpenXml.Office2010.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Color = System.Drawing.Color;

namespace Desktop
{
    public partial class FormRiwayat : Form
    {
        Helper helper = new Helper();
        private int id;

        public FormRiwayat()
        {
            InitializeComponent();
        }

        private void FormRiwayat_Load(object sender, EventArgs e)
        {
            panel_detail.Location = new Point(0, 0);

            panel_detail2.Location = new Point(0, 0);
            panel_detail2.Hide();

            panel_cek.Location = new Point(0, 0);
            panel_cek.Hide();

            ComboBoxSet();
            rb_tahun_ini_cek.Checked = true;

            id = Session_login.id;
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_kelas.nama as Kelas from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama.Text = row["nama"].ToString();
            lb_kelas.Text = row["kelas"].ToString();
            lb_nis.Text = row["nis"].ToString();
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto_detail.Image = null;
            }
            else
            {
                pb_foto_detail.Image = helper.ByteToImage((byte[])row["foto"]);
            }


            dgv_history_pembayaraan.DataSource = helper.GetTable($"Select bulan_dibayar as Bulan, keterangan as [Kategori SPP],  nominal as Nominal, sum(jumlah_bayar) as Jumlah, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status ORDER BY tbl_pembayaran.Status");
            if (dgv_history_pembayaraan.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
        }

        private void ComboBoxSet()
        {
            cbox_bulan_detail.Items.Add("january");
            cbox_bulan_detail.Items.Add("february");
            cbox_bulan_detail.Items.Add("march");
            cbox_bulan_detail.Items.Add("april");
            cbox_bulan_detail.Items.Add("may");
            cbox_bulan_detail.Items.Add("june");
            cbox_bulan_detail.Items.Add("july");
            cbox_bulan_detail.Items.Add("august");
            cbox_bulan_detail.Items.Add("september");
            cbox_bulan_detail.Items.Add("october");
            cbox_bulan_detail.Items.Add("november");
            cbox_bulan_detail.Items.Add("december");

            cbox_bulan_detail.SelectedIndex = 0;

            cbox_spp_detail.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp_detail.ValueMember = "id";
            cbox_spp_detail.DisplayMember = "keterangan";

            cbox_spp_cek.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp_cek.ValueMember = "id";
            cbox_spp_cek.DisplayMember = "keterangan";

            check_showall_detail.Checked = true;
        }

        private void SearchDetail()
        {
            if (check_showall_detail.Checked == true)
            {
                dgv_history_pembayaraan.DataSource = helper.GetTable($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status ORDER BY tbl_pembayaran.Status");
            }
            else
            {
                string spp_detail = "";
                string bulan_detail = "";
                if (check_bulan_detail.Checked == true)
                {
                    bulan_detail = $"and bulan_dibayar = '{cbox_bulan_detail.Text}'";
                }
                if (check_spp_detail.Checked == true)
                {
                    spp_detail = $"and id_spp = {cbox_spp_detail.SelectedValue}";
                }
                SqlCommand cmd = new SqlCommand($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} {spp_detail} {bulan_detail} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status ORDER BY tbl_pembayaran.Status");
                dgv_history_pembayaraan.DataSource = helper.GetTableCmd(cmd);
                if (dgv_history_pembayaraan.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel_detail2.Hide();
            panel_detail.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dgv_history_pembayaraan.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }

            panel_detail.Hide();
            panel_detail2.Show();

            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_kelas.nama as Kelas from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama_detail2.Text = row["nama"].ToString();
            lb_bulan_detail2.Text = dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[0].Value.ToString();
            lb_kategori_detail2.Text = dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[1].Value.ToString();
            int tanggungan = int.Parse(dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[2].Value.ToString()) - int.Parse(dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[3].Value.ToString());
            lb_tanggungan_detail2.Text = tanggungan.ToString();
            string status = "Lunas";
            if (tanggungan > 0)
            {
                status = "Belum Lunas";
            }
            lb_status_detail2.Text = status;


            dgv_history_pembayaran_detail2.DataSource = helper.GetTable($"Select tbl_pembayaran.id as ID, tanggal_pembayaran as Date, jumlah_bayar as Amount, tbl_petugas.nama as Staff from tbl_pembayaran inner join tbl_petugas on tbl_petugas.id = tbl_pembayaran.id_petugas inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} and bulan_dibayar = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[0].Value}' and keterangan = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[1].Value}'");
        }

        private void cbox_bulan_detail_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void check_bulan_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();

        }

        private void check_spp_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();

        }

        private void cbox_spp_detail_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchDetail();

        }

        private void check_showall_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();

        }

        private void dgv_history_pembayaraan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel_detail.Hide();
            panel_cek.Show();

            cekLunas();
        }

        private void rb_tahun_ini_cek_CheckedChanged(object sender, EventArgs e)
        {
            panel13.Hide();
            cbox_spp_cek.Enabled = false;

            cekLunas();
        }

        private void rb_tahun_lainnya_cek_CheckedChanged(object sender, EventArgs e)
        {
            panel13.Show();
            cbox_spp_cek.Enabled = true;

            cekLunas();
        }

        private void cbox_spp_cek_SelectedIndexChanged(object sender, EventArgs e)
        {
            cekLunas();
        }

        private void cekLunas()
        {
            int id_spp1 = 0;
            id = Session_login.id;
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_spp.keterangan as Kategori, nominal as Nominal from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama_cek.Text = row["nama"].ToString();
            lb_kategori_cek.Text = row["kategori"].ToString();
            lb_nominal_cek.Text = row["nominal"].ToString();
            if (rb_tahun_ini_cek.Checked)
            {
                id_spp1 = int.Parse(row["id_spp"].ToString());
            }
            else if (rb_tahun_lainnya_cek.Checked)
            {
                id_spp1 = int.Parse(cbox_spp_cek.SelectedValue.ToString());
            }
            string[] months = new string[] { "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december" };

            foreach (string month in months)
            {
                DataTable dtmonth = helper.GetTable($@"
        Select bulan_dibayar as Bulan, keterangan as [Kategori SPP], nominal as Nominal, 
        sum(jumlah_bayar) as Jumlah, tbl_pembayaran.status as Status 
        from tbl_pembayaran 
        inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp 
        where id_siswa = {id} and bulan_dibayar = '{month}' and id_spp = {id_spp1} 
        GROUP BY bulan_dibayar, tahun_dibayar, keterangan, nominal, tbl_pembayaran.status 
        ORDER BY tbl_pembayaran.status");

                if (dtmonth.Rows.Count > 0)
                {
                    DataRow monthrow = dtmonth.Rows[0];
                    Label label = null;

                    switch (month)
                    {
                        case "january": label = lb_january; break;
                        case "february": label = lb_february; break;
                        case "march": label = lb_march; break;
                        case "april": label = lb_april; break;
                        case "may": label = lb_may; break;
                        case "june": label = lb_june; break;
                        case "july": label = lb_july; break;
                        case "august": label = lb_august; break;
                        case "september": label = lb_september; break;
                        case "october": label = lb_october; break;
                        case "november": label = lb_november; break;
                        case "december": label = lb_december; break;
                    }

                    label.Text = monthrow["status"].ToString();

                    if (label.Text == "Not paid yet")
                    {
                        label.Text = "-" + Convert.ToInt32((Convert.ToInt32(monthrow["Jumlah"]) - Convert.ToInt32(monthrow["nominal"])) * -1);
                        label.ForeColor = Color.Red;
                    }
                    else
                    {
                        label.Text = "Paid";
                        label.ForeColor = Color.Green;
                    }
                }
                else
                {
                    Label label = null;

                    switch (month)
                    {
                        case "january": label = lb_january; break;
                        case "february": label = lb_february; break;
                        case "march": label = lb_march; break;
                        case "april": label = lb_april; break;
                        case "may": label = lb_may; break;
                        case "june": label = lb_june; break;
                        case "july": label = lb_july; break;
                        case "august": label = lb_august; break;
                        case "september": label = lb_september; break;
                        case "october": label = lb_october; break;
                        case "november": label = lb_november; break;
                        case "december": label = lb_december; break;
                    }

                    label.ForeColor = Color.Red;
                    label.Text = "Not paid yet";
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            panel_cek.Hide();
            panel_detail.Show();
        }
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Desktop
{
    public partial class FormPembayaran : Form
    {
        string keterangan1 = "";
        int id_spp1, tahun1, nominal1, id_siswa, id = 0;
        Helper helper = new Helper();
        public FormPembayaran()
        {
            InitializeComponent();
        }

        private void FormPembayaran_Load(object sender, EventArgs e)
        {
            if(Session_login.role == "petugas")
            {
                button10.Hide();
                button11.Hide();
                button14.Hide();
            }

            panel2.Location = new Point(0, 0);
            panel2.Hide();

            panel_detail.Location = new Point(0, 0);
            panel_detail.Hide();

            panel_detail2.Location = new Point(0, 0);
            panel_detail2.Hide();

            panel4.Location = new Point(0, 0);
            panel4.Hide();

            panel_cek.Location = new Point(0, 0);
            panel_cek.Hide();

            CheckedShowall();
            LoadDgv();
            ComboBoxSet();

            rb_tahun_ini.Checked = true;
            rb_tahun_ini_cek.Checked = true;
            panel8.Hide();
            panel13.Hide();
        }

        private void ComboBoxSet()
        {
            cbox_search.DataSource = helper.GetTable("select * from tbl_kelas where status = 1");
            cbox_search.ValueMember= "id";
            cbox_search.DisplayMember= "nama";

            cbox_spp.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp.ValueMember = "id";
            cbox_spp.DisplayMember = "keterangan";

            cbox_spp_cek.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp_cek.ValueMember = "id";
            cbox_spp_cek.DisplayMember = "keterangan";

            cbox_spp_detail.DataSource = helper.GetTable("select * from tbl_spp where status = 1");
            cbox_spp_detail.ValueMember = "id";
            cbox_spp_detail.DisplayMember = "keterangan";

            cbox_bulan.Items.Add("january");
            cbox_bulan.Items.Add("february");
            cbox_bulan.Items.Add("march");
            cbox_bulan.Items.Add("april");
            cbox_bulan.Items.Add("may");
            cbox_bulan.Items.Add("june");
            cbox_bulan.Items.Add("july");
            cbox_bulan.Items.Add("august");
            cbox_bulan.Items.Add("september");
            cbox_bulan.Items.Add("october");
            cbox_bulan.Items.Add("november");
            cbox_bulan.Items.Add("desember");

            cbox_bulan.SelectedIndex = 0;

            cbox_bulan_detail.Items.Add("january");
            cbox_bulan_detail.Items.Add("february");
            cbox_bulan_detail.Items.Add("march");
            cbox_bulan_detail.Items.Add("april");
            cbox_bulan_detail.Items.Add("may");
            cbox_bulan_detail.Items.Add("june");
            cbox_bulan_detail.Items.Add("july");
            cbox_bulan_detail.Items.Add("august");
            cbox_bulan_detail.Items.Add("september");
            cbox_bulan_detail.Items.Add("october");
            cbox_bulan_detail.Items.Add("november");
            cbox_bulan_detail.Items.Add("desember");

            cbox_bulan_detail.SelectedIndex = 0;

            rb_tahun_ini.Checked = true;
        }

        private void LoadDgv()
        {
            dgv_pembayaran.DataSource = helper.GetTable("select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tbl_siswa.status = 1 Order by tbl_kelas.nama");
            dgv_riwayat_semua.DataSource = helper.GetTable("exec SelectAllHistory");
            if (dgv_pembayaran.Rows.Count > 0)
            {
                panel_not_found.Hide();
            }
            else
            {
                panel_not_found.Show();
            }
            if (dgv_riwayat_semua.Rows.Count > 0)
            {
                panel6.Hide();
            }
            else
            {
                panel6.Show();
            }
        }

        private void CheckedShowall()
        {
            check_showall.Checked = true;
            check_showall_detail.Checked = true;
            if (check_showall.Checked)
            {
                LoadDgv();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv_pembayaran.Rows.Count == 0)
            {
                return;
            }
            panel1.Hide();
            panel2.Show();


            id_siswa = int.Parse(dgv_pembayaran.Rows[dgv_pembayaran.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_kelas.nama as Kelas, nominal, keterangan from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp where tbl_siswa.id = {id_siswa}");
            DataRow row = dt.Rows[0];
            lb_nama_bayar.Text = row["nama"].ToString();
            lb_kategori_bayar.Text = row["keterangan"].ToString();
            lb_nominal_bayar.Text = row["nominal"].ToString();
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto_bayar.Image = null;
            }
            else
            {
                pb_foto_bayar.Image = helper.ByteToImage((byte[])row["foto"]);
            }

            tbox_bayar.Text = "";
            dgv_bayar.Rows.Clear();
            if (dgv_bayar.Rows.Count <= 0)
            {
                panel_not_found_bayar.Show();
            }

            button7.Text = "Create";
        }

        private void rb_tahun_ini_CheckedChanged(object sender, EventArgs e)
        {
            panel8.Hide();
            cbox_spp.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel1.Show();
        }

        private void rb_tahun_lain_CheckedChanged(object sender, EventArgs e)
        {
            cbox_spp.Enabled = true;
            panel8.Show();
        }

        private void dgv_bayar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 0)
            {
                dgv_bayar.Rows.RemoveAt(e.RowIndex);
            }

            if (dgv_bayar.Rows.Count <= 0)
            {
                panel_not_found_bayar.Show();
            }
        }

        private void check_showall_CheckedChanged(object sender, EventArgs e)
        {
            if (check_showall.Checked)
            {
                LoadDgv();
            }
            else
            {
                dgv_pembayaran.DataSource = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue} and tbl_siswa.nama like '%{tbox_search.Text}%' and tbl_siswa.status = 1");
                if (dgv_pembayaran.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void check_showall_siswa_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void cbox_search_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (check_showall.Checked)
            {
                LoadDgv();
            }
            else
            {
                dgv_pembayaran.DataSource = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue} and tbl_siswa.nama like '%{tbox_search.Text}%' and tbl_siswa.status = 1");
                if (dgv_pembayaran.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void tbox_search_TextChanged(object sender, EventArgs e)
        {
            if (check_showall.Checked)
            {
                LoadDgv();
            }
            else
            {
                dgv_pembayaran.DataSource = helper.GetTable($"select tbl_siswa.id as ID, tbl_siswa.nama as Name, tbl_kelas.nama as Class, tbl_spp.keterangan as [Fee category], nisn as NISN from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where id_kelas = {cbox_search.SelectedValue} and tbl_siswa.nama like '%{tbox_search.Text}%' and tbl_siswa.status = 1");
                if (dgv_pembayaran.Rows.Count > 0)
                {
                    panel_not_found.Hide();
                }
                else
                {
                    panel_not_found.Show();
                }
            }
        }

        private void cbox_kelas_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tbox_nama_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel_detail.Hide();
            panel1.Show();
        }

        private void SearchDetail()
        {
            if (check_showall_detail.Checked == true)
            {
                dgv_history_pembayaraan.DataSource = helper.GetTable($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status");
                if (dgv_history_pembayaraan.Rows.Count > 0)
                {
                    panel_not_found_detail.Hide();
                }
                else
                {
                    panel_not_found_detail.Show();
                }
            }
            else
            {
                string spp_detail = "";
                string bulan_detail = "";
                if (check_bulan_detail.Checked == true)
                {
                    bulan_detail = $"and bulan_dibayar = '{cbox_bulan_detail.Text}'";
                }
                if (check_spp_detail.Checked == true)
                {
                    spp_detail = $"and id_spp = {cbox_spp_detail.SelectedValue}";
                }
                SqlCommand cmd = new SqlCommand($"Select bulan_dibayar as Month, keterangan as [Fee category], nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} {spp_detail} {bulan_detail} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status");
                dgv_history_pembayaraan.DataSource = helper.GetTableCmd(cmd);
                if (dgv_history_pembayaraan.Rows.Count > 0)
                {
                    panel_not_found_detail.Hide();
                }
                else
                {
                    panel_not_found_detail.Show();
                }
            }
        }
        
        private void check_showall_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void cbox_bulan_detail_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void cbox_spp_detail_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void check_bulan_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void check_spp_detail_CheckedChanged(object sender, EventArgs e)
        {
            SearchDetail();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dgv_history_pembayaraan.Rows.Count == 0)
            {
                MessageBox.Show("Data none.");
                return;
            }
            
            panel_detail.Hide();
            panel_detail2.Show();


            id = int.Parse(dgv_pembayaran.Rows[dgv_pembayaran.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_kelas.nama as Kelas from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama_detail2.Text = row["nama"].ToString();
            lb_bulan_detail2.Text = dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[0].Value.ToString();
            lb_kategori_detail2.Text = dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[1].Value.ToString();
            int tanggungan = int.Parse(dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[2].Value.ToString()) - int.Parse(dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[3].Value.ToString());
            lb_tanggungan_detail2.Text = tanggungan.ToString();
            string status = "Paid";
            if(tanggungan > 0)
            {
                status = "Not paid yet";
            }
            lb_status_detail2.Text = status;


            dgv_history_pembayaran_detail2.DataSource = helper.GetTable($"Select tbl_pembayaran.id as ID, tanggal_pembayaran as Date, jumlah_bayar as Amount, tbl_petugas.nama as Staff from tbl_pembayaran inner join tbl_petugas on tbl_petugas.id = tbl_pembayaran.id_petugas inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} and bulan_dibayar = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[0].Value}' and keterangan = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[1].Value}'");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel_detail2.Hide();
            panel_detail.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure to delete this data?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                var res = helper.Insert($"Delete from tbl_pembayaran where id = {dgv_history_pembayaran_detail2.Rows[dgv_history_pembayaran_detail2.CurrentCell.RowIndex].Cells[0].Value}");

                dgv_history_pembayaran_detail2.DataSource = helper.GetTable($"Select tbl_pembayaran.id as ID, tanggal_pembayaran as Date, jumlah_bayar as Amount, tbl_petugas.nama as Staff from tbl_pembayaran inner join tbl_petugas on tbl_petugas.id = tbl_pembayaran.id_petugas inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} and bulan_dibayar = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[0].Value}' and keterangan = '{dgv_history_pembayaraan.Rows[dgv_history_pembayaraan.CurrentCell.RowIndex].Cells[1].Value}'");

                dgv_history_pembayaraan.DataSource = helper.GetTable($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status");

                panel_detail2.Hide();
                panel_detail.Show();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            helper.ExportExcel(helper.GetTable($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status"));
        }

        private void button15_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel4.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            helper.ExportExcel(helper.GetTable($"Select tbl_petugas.nama, tbl_siswa.nama, tbl_kelas.nama, tanggal_pembayaran, bulan_dibayar, tahun_dibayar, keterangan, jumlah_bayar from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp inner join tbl_siswa on tbl_siswa.id = tbl_pembayaran.id_siswa inner join tbl_petugas on tbl_petugas.id = tbl_pembayaran.id_petugas inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas"));
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgv_history_pembayaran_detail2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_pembayaran_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            panel_cek.Show();
            panel_cek.BringToFront();

            cekLunas();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            panel_cek.Hide();
        }

        private void rb_tahun_ini_cek_CheckedChanged(object sender, EventArgs e)
        {
            panel13.Hide();
            cbox_spp_cek.Enabled = false;

            cekLunas();
        }

        private void rb_tahun_lainnya_cek_CheckedChanged(object sender, EventArgs e)
        {
            panel13.Show();
            cbox_spp_cek.Enabled = true;

            cekLunas();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel4.Show();
        }

        private void cbox_spp_cek_SelectedIndexChanged(object sender, EventArgs e)
        {
            cekLunas();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (dgv_pembayaran.Rows.Count == 0)
            {
                return;
            }
            panel_cek.Show();
            panel_cek.BringToFront();

            cekLunas();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            panel_cek.Show();
            panel_cek.BringToFront();

            cekLunas();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dgv_pembayaran.Rows.Count == 0)
            {
                MessageBox.Show("Data Tidak ada.");
                return;
            }

            panel1.Hide();
            panel_detail.Show();

            id = int.Parse(dgv_pembayaran.Rows[dgv_pembayaran.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_kelas.nama as Kelas, nominal, keterangan from tbl_siswa inner join tbl_kelas on tbl_kelas.id = tbl_siswa.id_kelas inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama.Text = row["nama"].ToString();
            lb_kategori.Text = row["keterangan"].ToString();
            lb_nominal.Text = row["nominal"].ToString();
            if (string.IsNullOrEmpty(row["foto"].ToString()))
            {
                pb_foto_detail.Image = null;
            }
            else
            {
                pb_foto_detail.Image = helper.ByteToImage((byte[])row["foto"]);
            }


            dgv_history_pembayaraan.DataSource = helper.GetTable($"Select bulan_dibayar as Month, keterangan as [Fee category],  nominal as Nominal, sum(jumlah_bayar) as Amount, tbl_pembayaran.status as Status from tbl_pembayaran inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp where id_siswa = {id} GROUP BY bulan_dibayar, tahun_dibayar, keterangan,nominal, tbl_pembayaran.status ORDER BY tbl_pembayaran.status");
            if (dgv_history_pembayaraan.Rows.Count > 0)
            {
                panel_not_found_detail.Hide();
            }
            else
            {
                panel_not_found_detail.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (helper.NumberValidation(tbox_bayar, "Payment Amount") == 0)
            {
                return;
            }

            if (int.Parse(tbox_bayar.Text) < 10000)
            {
                MessageBox.Show("Sorry Minimum Payment is 10000");
                return;
            }

            
            if (tbox_bayar.Text.Length == 0)
            {
                MessageBox.Show("Blank Quantity Data.");
                return;
            }

            // Check Double item
            for(int i = 0; i < dgv_bayar.Rows.Count; i++)
            {
                if(rb_tahun_lain.Checked == true)
                {
                    DataTable dt = helper.GetTable($"Select * from tbl_spp where id = {cbox_spp.SelectedValue}");
                    DataRow row = dt.Rows[0];
                    keterangan1 = row["Keterangan"].ToString();
                }

                if(cbox_bulan.Text == dgv_bayar.Rows[i].Cells["bulan_bayar"].Value.ToString() && keterangan1 == dgv_bayar.Rows[i].Cells["keterangan_spp"].Value.ToString())
                {
                    MessageBox.Show("Data Already Exists.");
                    return;
                }
            }

            // Get id_spp by rb tahun ini
            if (rb_tahun_ini.Checked == true)
            {

                if (id_siswa == 0)
                {
                    MessageBox.Show("No Student Data selected.");
                    return;
                }
                else
                {
                    DataTable dt = helper.GetTable($"select * from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp where tbl_siswa.id = {id_siswa}");
                    DataRow row = dt.Rows[0];
                    id_spp1 = int.Parse(row["id_spp"].ToString());
                    tahun1 = int.Parse(row["tahun"].ToString());
                    nominal1 = int.Parse(row["nominal"].ToString());
                    keterangan1 = row["keterangan"].ToString();
                }
            }

            // Get id_spp by rb tahun lainnya
            if (rb_tahun_lain.Checked == true)
            {

                if (id_siswa == 0)
                {
                    MessageBox.Show("No Student Data selected.");
                    return;
                }
                else
                {
                    id_spp1 = int.Parse(cbox_spp.SelectedValue.ToString());
                    DataTable dt = helper.GetTable($"select * from tbl_spp where id = {id_spp1}");
                    DataRow row = dt.Rows[0];
                    tahun1 = int.Parse(row["tahun"].ToString());
                    nominal1 = int.Parse(row["nominal"].ToString());
                    keterangan1 = row["keterangan"].ToString();
                }
            }

            int limit_bayar = 0;
            int limit_nominal = 0;
            int tanggungan = 0;

            DataTable dt2 = helper.GetTable($"select nominal from tbl_spp where id = {id_spp1}");
            if (dt2.Rows.Count > 0)
            {
                DataRow row = dt2.Rows[0];
                limit_nominal = int.Parse(row["nominal"].ToString());
            }

            DataTable dt1 = helper.GetTable($"select sum(jumlah_bayar) as sum from tbl_pembayaran where id_spp = {id_spp1} and id_siswa = {id_siswa} and bulan_dibayar = '{cbox_bulan.Text}'");
            DataRow row1 = dt1.Rows[0];
            if (string.IsNullOrEmpty(row1["sum"].ToString()))
            {
                limit_bayar = 0;
            }
            else
            {
                limit_bayar = int.Parse(row1["sum"].ToString());
            }

            if (limit_bayar == limit_nominal)
            {
                MessageBox.Show($"{cbox_bulan.Text}, Fee category ({keterangan1}) already paid");
                return;
            }

            tanggungan = int.Parse(tbox_bayar.Text) + limit_bayar - limit_nominal;

            if (0 < tanggungan)
            {
                MessageBox.Show($"{cbox_bulan.Text}, Fee category ({keterangan1}) has more {tanggungan}");
                return;
            }

            dgv_bayar.Rows.Add("" ,id_spp1, cbox_bulan.Text, tahun1, keterangan1, nominal1, tbox_bayar.Text);

            if(dgv_bayar.Rows.Count > 0)
            {
                panel_not_found_bayar.Hide();
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (dgv_bayar.Rows.Count == 0)
            {
                MessageBox.Show("Payment Data is Empty.");
                return;
            }

            int total = 0;
            for(int i = 0; i < dgv_bayar.Rows.Count; i++)
            {
                total = total + Convert.ToInt32(dgv_bayar.Rows[i].Cells["jumlah_bayar"].Value);
            }

            if(MessageBox.Show($"The total costs required are {total}","Confirmation", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {

            }
            else
            {
                return;
            }

            for(int i = 0; i < dgv_bayar.Rows.Count; i++)
            {
                int limit_bayar = 0;
                int limit_nominal = 0;
                int tanggungan = 0;

                DataTable dt = helper.GetTable($"select nominal from tbl_spp where id = {dgv_bayar.Rows[i].Cells["id_spp"].Value}");
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    limit_nominal = int.Parse(row["nominal"].ToString());
                }

                DataTable dt1 = helper.GetTable($"select sum(jumlah_bayar) as sum from tbl_pembayaran where id_spp = {dgv_bayar.Rows[i].Cells["id_spp"].Value} and id_siswa = {id_siswa} and bulan_dibayar = '{dgv_bayar.Rows[i].Cells["bulan_bayar"].Value}'");
                DataRow row1 = dt1.Rows[0];
                if (string.IsNullOrEmpty(row1["sum"].ToString()))
                {
                    limit_bayar = 0;
                }
                else
                {
                    limit_bayar = int.Parse(row1["sum"].ToString());
                }

                if(limit_bayar == limit_nominal)
                {
                    MessageBox.Show($"{dgv_bayar.Rows[i].Cells["bulan_bayar"].Value}, Fee category {dgv_bayar.Rows[i].Cells["keterangan_spp"].Value} Paid");
                    return;
                }

                tanggungan = int.Parse(dgv_bayar.Rows[i].Cells["jumlah_bayar"].Value.ToString()) + limit_bayar - limit_nominal;

                if(0 < tanggungan)
                {
                    MessageBox.Show($"{dgv_bayar.Rows[i].Cells["bulan_bayar"].Value}, Fee category {dgv_bayar.Rows[i].Cells["keterangan_spp"].Value} over {tanggungan}");
                    return;
                }
            }

            for(int i = 0; i < dgv_bayar.Rows.Count; i++)
            {

                string insert = $"insert into tbl_pembayaran values({Session_login.id},{id_siswa},@datenow,'{dgv_bayar.Rows[i].Cells["bulan_bayar"].Value}',{dgv_bayar.Rows[i].Cells["tahun_bayar"].Value},{dgv_bayar.Rows[i].Cells["jumlah_bayar"].Value},{dgv_bayar.Rows[i].Cells["id_spp"].Value}, '')";
                SqlCommand cmd = new SqlCommand(insert);
                cmd.Parameters.AddWithValue("@datenow", DateTime.Now);
                try
                {
                    var res = helper.InsertCmd(cmd);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
            }

            panel2.Hide();
            panel1.Show();
            MessageBox.Show("Data Added Successfully.");
        }

        private void cekLunas()
        {
            if (dgv_pembayaran.Rows.Count == 0)
            {
                return;
            }
            id = int.Parse(dgv_pembayaran.Rows[dgv_pembayaran.CurrentCell.RowIndex].Cells[0].Value.ToString());
            DataTable dt = helper.GetTable($"Select tbl_siswa.*, tbl_spp.keterangan as Kategori, nominal as Nominal from tbl_siswa inner join tbl_spp on tbl_spp.id = tbl_siswa.id_spp where tbl_siswa.id = {id}");
            DataRow row = dt.Rows[0];
            lb_nama_cek.Text = row["nama"].ToString();
            lb_kategori_cek.Text = row["kategori"].ToString();
            lb_nominal_cek.Text = row["nominal"].ToString();
            if (rb_tahun_ini_cek.Checked)
            {
                id_spp1 = int.Parse(row["id_spp"].ToString());
            }
            else if (rb_tahun_lainnya_cek.Checked)
            {
                id_spp1 = int.Parse(cbox_spp_cek.SelectedValue.ToString());
            }
            string[] months = new string[] { "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december" };

            foreach (string month in months)
            {
                DataTable dtmonth = helper.GetTable($@"
        Select bulan_dibayar as Bulan, keterangan as [Kategori SPP], nominal as Nominal, 
        sum(jumlah_bayar) as Jumlah, tbl_pembayaran.status as Status 
        from tbl_pembayaran 
        inner join tbl_spp on tbl_spp.id = tbl_pembayaran.id_spp 
        where id_siswa = {id} and bulan_dibayar = '{month}' and id_spp = {id_spp1} 
        GROUP BY bulan_dibayar, tahun_dibayar, keterangan, nominal, tbl_pembayaran.status 
        ORDER BY tbl_pembayaran.status");

                if (dtmonth.Rows.Count > 0)
                {
                    DataRow monthrow = dtmonth.Rows[0];
                    Label label = null;

                    switch (month)
                    {
                        case "january": label = lb_january; break;
                        case "february": label = lb_february; break;
                        case "march": label = lb_march; break;
                        case "april": label = lb_april; break;
                        case "may": label = lb_may; break;
                        case "june": label = lb_june; break;
                        case "july": label = lb_july; break;
                        case "august": label = lb_august; break;
                        case "september": label = lb_september; break;
                        case "october": label = lb_october; break;
                        case "november": label = lb_november; break;
                        case "december": label = lb_december; break;
                    }

                    label.Text = monthrow["status"].ToString();

                    if (label.Text == "Not paid yet")
                    {
                        label.Text = "-" + Convert.ToInt32((Convert.ToInt32(monthrow["Jumlah"]) - Convert.ToInt32(monthrow["nominal"])) * -1);
                        label.ForeColor = Color.Red;
                    }
                    else
                    {
                        label.Text = "Paid";
                        label.ForeColor = Color.Green;
                    }
                }
                else
                {
                    Label label = null;

                    switch (month)
                    {
                        case "january": label = lb_january; break;
                        case "february": label = lb_february; break;
                        case "march": label = lb_march; break;
                        case "april": label = lb_april; break;
                        case "may": label = lb_may; break;
                        case "june": label = lb_june; break;
                        case "july": label = lb_july; break;
                        case "august": label = lb_august; break;
                        case "september": label = lb_september; break;
                        case "october": label = lb_october; break;
                        case "november": label = lb_november; break;
                        case "december": label = lb_december; break;
                    }

                    label.ForeColor = Color.Red;
                    label.Text = "Not paid yet";
                }
            }

        }
    }
}

﻿namespace Desktop
{
    partial class FormPembayaran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPembayaran));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.panel_not_found_bayar = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pb_foto_bayar = new System.Windows.Forms.PictureBox();
            this.lb_nominal_bayar = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_nama_bayar = new System.Windows.Forms.Label();
            this.lb_kategori_bayar = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.cbox_spp = new System.Windows.Forms.ComboBox();
            this.rb_tahun_lain = new System.Windows.Forms.RadioButton();
            this.rb_tahun_ini = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tbox_bayar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cbox_bulan = new System.Windows.Forms.ComboBox();
            this.dgv_bayar = new System.Windows.Forms.DataGridView();
            this.Remove = new System.Windows.Forms.DataGridViewButtonColumn();
            this.id_spp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bulan_bayar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tahun_bayar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keterangan_spp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nominal_bayar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlah_bayar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_detail = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.panel_not_found_detail = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.check_spp_detail = new System.Windows.Forms.CheckBox();
            this.cbox_spp_detail = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.check_bulan_detail = new System.Windows.Forms.CheckBox();
            this.cbox_bulan_detail = new System.Windows.Forms.ComboBox();
            this.check_showall_detail = new System.Windows.Forms.CheckBox();
            this.dgv_history_pembayaraan = new System.Windows.Forms.DataGridView();
            this.pb_foto_detail = new System.Windows.Forms.PictureBox();
            this.lb_nominal = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_kategori = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.panel_not_found = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tbox_search = new System.Windows.Forms.TextBox();
            this.check_showall = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.dgv_pembayaran = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbox_search = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_detail2 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.lb_tanggungan_detail2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lb_status_detail2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.dgv_history_pembayaran_detail2 = new System.Windows.Forms.DataGridView();
            this.lb_kategori_detail2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lb_nama_detail2 = new System.Windows.Forms.Label();
            this.lb_bulan_detail2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button14 = new System.Windows.Forms.Button();
            this.dgv_riwayat_semua = new System.Windows.Forms.DataGridView();
            this.button15 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.panel_cek = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.lb_december = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.lb_august = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.lb_april = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.lb_november = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.lb_july = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.lb_march = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.lb_october = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.lb_june = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.lb_february = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.lb_september = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.lb_may = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.lb_january = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.cbox_spp_cek = new System.Windows.Forms.ComboBox();
            this.rb_tahun_lainnya_cek = new System.Windows.Forms.RadioButton();
            this.rb_tahun_ini_cek = new System.Windows.Forms.RadioButton();
            this.lb_nominal_cek = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lb_nama_cek = new System.Windows.Forms.Label();
            this.lb_kategori_cek = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel_not_found_bayar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_bayar)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_bayar)).BeginInit();
            this.panel_detail.SuspendLayout();
            this.panel_not_found_detail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaraan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel_not_found.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pembayaran)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel_detail2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaran_detail2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_riwayat_semua)).BeginInit();
            this.panel_cek.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.button17);
            this.panel2.Controls.Add(this.panel_not_found_bayar);
            this.panel2.Controls.Add(this.pb_foto_bayar);
            this.panel2.Controls.Add(this.lb_nominal_bayar);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.lb_nama_bayar);
            this.panel2.Controls.Add(this.lb_kategori_bayar);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.rb_tahun_lain);
            this.panel2.Controls.Add(this.rb_tahun_ini);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.dgv_bayar);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(896, 17);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(712, 787);
            this.panel2.TabIndex = 47;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Green;
            this.button17.FlatAppearance.BorderSize = 2;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(29, 728);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(126, 37);
            this.button17.TabIndex = 84;
            this.button17.Text = "Check Paid";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // panel_not_found_bayar
            // 
            this.panel_not_found_bayar.Controls.Add(this.label23);
            this.panel_not_found_bayar.Controls.Add(this.pictureBox4);
            this.panel_not_found_bayar.Location = new System.Drawing.Point(40, 516);
            this.panel_not_found_bayar.Name = "panel_not_found_bayar";
            this.panel_not_found_bayar.Size = new System.Drawing.Size(640, 149);
            this.panel_not_found_bayar.TabIndex = 83;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(261, 120);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(125, 17);
            this.label23.TabIndex = 78;
            this.label23.Text = "Data not found ...";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(175, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(340, 117);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 77;
            this.pictureBox4.TabStop = false;
            // 
            // pb_foto_bayar
            // 
            this.pb_foto_bayar.BackColor = System.Drawing.Color.White;
            this.pb_foto_bayar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto_bayar.Location = new System.Drawing.Point(532, 54);
            this.pb_foto_bayar.Name = "pb_foto_bayar";
            this.pb_foto_bayar.Size = new System.Drawing.Size(120, 120);
            this.pb_foto_bayar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto_bayar.TabIndex = 63;
            this.pb_foto_bayar.TabStop = false;
            // 
            // lb_nominal_bayar
            // 
            this.lb_nominal_bayar.AutoSize = true;
            this.lb_nominal_bayar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal_bayar.ForeColor = System.Drawing.Color.Black;
            this.lb_nominal_bayar.Location = new System.Drawing.Point(387, 235);
            this.lb_nominal_bayar.Name = "lb_nominal_bayar";
            this.lb_nominal_bayar.Size = new System.Drawing.Size(52, 25);
            this.lb_nominal_bayar.TabIndex = 62;
            this.lb_nominal_bayar.Text = "Text";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(384, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 61;
            this.label5.Text = "Fee nominal";
            // 
            // lb_nama_bayar
            // 
            this.lb_nama_bayar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama_bayar.ForeColor = System.Drawing.Color.Black;
            this.lb_nama_bayar.Location = new System.Drawing.Point(48, 162);
            this.lb_nama_bayar.Name = "lb_nama_bayar";
            this.lb_nama_bayar.Size = new System.Drawing.Size(454, 25);
            this.lb_nama_bayar.TabIndex = 60;
            this.lb_nama_bayar.Text = "Text";
            // 
            // lb_kategori_bayar
            // 
            this.lb_kategori_bayar.AutoSize = true;
            this.lb_kategori_bayar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori_bayar.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori_bayar.Location = new System.Drawing.Point(48, 234);
            this.lb_kategori_bayar.Name = "lb_kategori_bayar";
            this.lb_kategori_bayar.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori_bayar.TabIndex = 59;
            this.lb_kategori_bayar.Text = "Text";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(45, 138);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 17);
            this.label15.TabIndex = 58;
            this.label15.Text = "Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(45, 211);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 17);
            this.label21.TabIndex = 57;
            this.label21.Text = "Fee category";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.cbox_spp);
            this.panel8.Location = new System.Drawing.Point(331, 299);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(137, 36);
            this.panel8.TabIndex = 56;
            // 
            // cbox_spp
            // 
            this.cbox_spp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp.FormattingEnabled = true;
            this.cbox_spp.IntegralHeight = false;
            this.cbox_spp.Location = new System.Drawing.Point(4, 4);
            this.cbox_spp.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp.Name = "cbox_spp";
            this.cbox_spp.Size = new System.Drawing.Size(127, 25);
            this.cbox_spp.TabIndex = 43;
            // 
            // rb_tahun_lain
            // 
            this.rb_tahun_lain.AutoSize = true;
            this.rb_tahun_lain.Location = new System.Drawing.Point(186, 310);
            this.rb_tahun_lain.Name = "rb_tahun_lain";
            this.rb_tahun_lain.Size = new System.Drawing.Size(124, 17);
            this.rb_tahun_lain.TabIndex = 55;
            this.rb_tahun_lain.TabStop = true;
            this.rb_tahun_lain.Text = "Another fee category";
            this.rb_tahun_lain.UseVisualStyleBackColor = true;
            this.rb_tahun_lain.CheckedChanged += new System.EventHandler(this.rb_tahun_lain_CheckedChanged);
            // 
            // rb_tahun_ini
            // 
            this.rb_tahun_ini.AutoSize = true;
            this.rb_tahun_ini.Location = new System.Drawing.Point(59, 310);
            this.rb_tahun_ini.Name = "rb_tahun_ini";
            this.rb_tahun_ini.Size = new System.Drawing.Size(121, 17);
            this.rb_tahun_ini.TabIndex = 54;
            this.rb_tahun_ini.TabStop = true;
            this.rb_tahun_ini.Text = "Current fee category";
            this.rb_tahun_ini.UseVisualStyleBackColor = true;
            this.rb_tahun_ini.CheckedChanged += new System.EventHandler(this.rb_tahun_ini_CheckedChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(566, 372);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 39);
            this.button2.TabIndex = 51;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(369, 353);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 17);
            this.label6.TabIndex = 50;
            this.label6.Text = "Payment Amount";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.tbox_bayar);
            this.panel7.Location = new System.Drawing.Point(366, 373);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(194, 38);
            this.panel7.TabIndex = 49;
            // 
            // tbox_bayar
            // 
            this.tbox_bayar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_bayar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_bayar.Location = new System.Drawing.Point(8, 9);
            this.tbox_bayar.Name = "tbox_bayar";
            this.tbox_bayar.Size = new System.Drawing.Size(172, 19);
            this.tbox_bayar.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 353);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 48;
            this.label4.Text = "Month";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.cbox_bulan);
            this.panel5.Location = new System.Drawing.Point(40, 373);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(317, 38);
            this.panel5.TabIndex = 47;
            // 
            // cbox_bulan
            // 
            this.cbox_bulan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_bulan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_bulan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_bulan.FormattingEnabled = true;
            this.cbox_bulan.Location = new System.Drawing.Point(9, 4);
            this.cbox_bulan.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_bulan.Name = "cbox_bulan";
            this.cbox_bulan.Size = new System.Drawing.Size(298, 29);
            this.cbox_bulan.TabIndex = 43;
            // 
            // dgv_bayar
            // 
            this.dgv_bayar.AllowUserToAddRows = false;
            this.dgv_bayar.AllowUserToDeleteRows = false;
            this.dgv_bayar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_bayar.BackgroundColor = System.Drawing.Color.White;
            this.dgv_bayar.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_bayar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_bayar.ColumnHeadersHeight = 40;
            this.dgv_bayar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_bayar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Remove,
            this.id_spp,
            this.bulan_bayar,
            this.tahun_bayar,
            this.keterangan_spp,
            this.nominal_bayar,
            this.jumlah_bayar});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_bayar.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_bayar.EnableHeadersVisualStyles = false;
            this.dgv_bayar.GridColor = System.Drawing.Color.Black;
            this.dgv_bayar.Location = new System.Drawing.Point(29, 426);
            this.dgv_bayar.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_bayar.MultiSelect = false;
            this.dgv_bayar.Name = "dgv_bayar";
            this.dgv_bayar.ReadOnly = true;
            this.dgv_bayar.RowHeadersVisible = false;
            this.dgv_bayar.RowHeadersWidth = 51;
            this.dgv_bayar.RowTemplate.Height = 50;
            this.dgv_bayar.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_bayar.Size = new System.Drawing.Size(652, 280);
            this.dgv_bayar.TabIndex = 46;
            this.dgv_bayar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_bayar_CellContentClick);
            // 
            // Remove
            // 
            this.Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Remove.HeaderText = "Remove";
            this.Remove.Name = "Remove";
            this.Remove.ReadOnly = true;
            this.Remove.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Remove.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Remove.Text = "Remove";
            this.Remove.UseColumnTextForButtonValue = true;
            // 
            // id_spp
            // 
            this.id_spp.HeaderText = "ID";
            this.id_spp.Name = "id_spp";
            this.id_spp.ReadOnly = true;
            this.id_spp.Visible = false;
            // 
            // bulan_bayar
            // 
            this.bulan_bayar.HeaderText = "Month";
            this.bulan_bayar.Name = "bulan_bayar";
            this.bulan_bayar.ReadOnly = true;
            // 
            // tahun_bayar
            // 
            this.tahun_bayar.HeaderText = "Year";
            this.tahun_bayar.Name = "tahun_bayar";
            this.tahun_bayar.ReadOnly = true;
            // 
            // keterangan_spp
            // 
            this.keterangan_spp.FillWeight = 140F;
            this.keterangan_spp.HeaderText = "Fee category";
            this.keterangan_spp.Name = "keterangan_spp";
            this.keterangan_spp.ReadOnly = true;
            // 
            // nominal_bayar
            // 
            this.nominal_bayar.HeaderText = "Nominal";
            this.nominal_bayar.Name = "nominal_bayar";
            this.nominal_bayar.ReadOnly = true;
            // 
            // jumlah_bayar
            // 
            this.jumlah_bayar.FillWeight = 200F;
            this.jumlah_bayar.HeaderText = "Amount";
            this.jumlah_bayar.Name = "jumlah_bayar";
            this.jumlah_bayar.ReadOnly = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.BorderSize = 2;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Green;
            this.button6.Location = new System.Drawing.Point(423, 728);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(126, 37);
            this.button6.TabIndex = 31;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Green;
            this.button7.FlatAppearance.BorderSize = 2;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(555, 728);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(126, 37);
            this.button7.TabIndex = 30;
            this.button7.Text = "Create";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 41);
            this.label1.TabIndex = 23;
            this.label1.Text = "Payment";
            // 
            // panel_detail
            // 
            this.panel_detail.BackColor = System.Drawing.Color.White;
            this.panel_detail.Controls.Add(this.button13);
            this.panel_detail.Controls.Add(this.panel_not_found_detail);
            this.panel_detail.Controls.Add(this.button11);
            this.panel_detail.Controls.Add(this.button5);
            this.panel_detail.Controls.Add(this.label7);
            this.panel_detail.Controls.Add(this.panel10);
            this.panel_detail.Controls.Add(this.panel9);
            this.panel_detail.Controls.Add(this.check_showall_detail);
            this.panel_detail.Controls.Add(this.dgv_history_pembayaraan);
            this.panel_detail.Controls.Add(this.pb_foto_detail);
            this.panel_detail.Controls.Add(this.lb_nominal);
            this.panel_detail.Controls.Add(this.label17);
            this.panel_detail.Controls.Add(this.lb_nama);
            this.panel_detail.Controls.Add(this.lb_kategori);
            this.panel_detail.Controls.Add(this.label8);
            this.panel_detail.Controls.Add(this.label10);
            this.panel_detail.Controls.Add(this.button8);
            this.panel_detail.Controls.Add(this.label11);
            this.panel_detail.Location = new System.Drawing.Point(955, 11);
            this.panel_detail.Margin = new System.Windows.Forms.Padding(2);
            this.panel_detail.Name = "panel_detail";
            this.panel_detail.Size = new System.Drawing.Size(712, 787);
            this.panel_detail.TabIndex = 48;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Green;
            this.button13.FlatAppearance.BorderSize = 2;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(433, 684);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(126, 37);
            this.button13.TabIndex = 83;
            this.button13.Text = "Check paid";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // panel_not_found_detail
            // 
            this.panel_not_found_detail.Controls.Add(this.label12);
            this.panel_not_found_detail.Controls.Add(this.pictureBox2);
            this.panel_not_found_detail.Location = new System.Drawing.Point(33, 457);
            this.panel_not_found_detail.Name = "panel_not_found_detail";
            this.panel_not_found_detail.Size = new System.Drawing.Size(640, 149);
            this.panel_not_found_detail.TabIndex = 82;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(261, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 17);
            this.label12.TabIndex = 78;
            this.label12.Text = "Data not found ...";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(175, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(340, 117);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 77;
            this.pictureBox2.TabStop = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.FlatAppearance.BorderSize = 2;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.Green;
            this.button11.Location = new System.Drawing.Point(301, 684);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(126, 37);
            this.button11.TabIndex = 73;
            this.button11.Text = "Export Excel";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Green;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(565, 684);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(126, 37);
            this.button5.TabIndex = 68;
            this.button5.Text = "History";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 17);
            this.label7.TabIndex = 66;
            this.label7.Text = "Search";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.check_spp_detail);
            this.panel10.Controls.Add(this.cbox_spp_detail);
            this.panel10.Location = new System.Drawing.Point(344, 290);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(347, 38);
            this.panel10.TabIndex = 65;
            // 
            // check_spp_detail
            // 
            this.check_spp_detail.AutoSize = true;
            this.check_spp_detail.Location = new System.Drawing.Point(319, 12);
            this.check_spp_detail.Name = "check_spp_detail";
            this.check_spp_detail.Size = new System.Drawing.Size(15, 14);
            this.check_spp_detail.TabIndex = 69;
            this.check_spp_detail.UseVisualStyleBackColor = true;
            this.check_spp_detail.CheckedChanged += new System.EventHandler(this.check_spp_detail_CheckedChanged);
            // 
            // cbox_spp_detail
            // 
            this.cbox_spp_detail.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp_detail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp_detail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp_detail.FormattingEnabled = true;
            this.cbox_spp_detail.Location = new System.Drawing.Point(9, 4);
            this.cbox_spp_detail.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp_detail.Name = "cbox_spp_detail";
            this.cbox_spp_detail.Size = new System.Drawing.Size(300, 29);
            this.cbox_spp_detail.TabIndex = 43;
            this.cbox_spp_detail.SelectedIndexChanged += new System.EventHandler(this.cbox_spp_detail_SelectedIndexChanged);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.check_bulan_detail);
            this.panel9.Controls.Add(this.cbox_bulan_detail);
            this.panel9.Location = new System.Drawing.Point(22, 290);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(316, 38);
            this.panel9.TabIndex = 64;
            // 
            // check_bulan_detail
            // 
            this.check_bulan_detail.AutoSize = true;
            this.check_bulan_detail.Location = new System.Drawing.Point(288, 12);
            this.check_bulan_detail.Name = "check_bulan_detail";
            this.check_bulan_detail.Size = new System.Drawing.Size(15, 14);
            this.check_bulan_detail.TabIndex = 68;
            this.check_bulan_detail.UseVisualStyleBackColor = true;
            this.check_bulan_detail.CheckedChanged += new System.EventHandler(this.check_bulan_detail_CheckedChanged);
            // 
            // cbox_bulan_detail
            // 
            this.cbox_bulan_detail.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_bulan_detail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_bulan_detail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_bulan_detail.FormattingEnabled = true;
            this.cbox_bulan_detail.Location = new System.Drawing.Point(9, 4);
            this.cbox_bulan_detail.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_bulan_detail.Name = "cbox_bulan_detail";
            this.cbox_bulan_detail.Size = new System.Drawing.Size(269, 29);
            this.cbox_bulan_detail.TabIndex = 43;
            this.cbox_bulan_detail.SelectedIndexChanged += new System.EventHandler(this.cbox_bulan_detail_SelectedIndexChanged);
            // 
            // check_showall_detail
            // 
            this.check_showall_detail.AutoSize = true;
            this.check_showall_detail.Location = new System.Drawing.Point(31, 336);
            this.check_showall_detail.Name = "check_showall_detail";
            this.check_showall_detail.Size = new System.Drawing.Size(67, 17);
            this.check_showall_detail.TabIndex = 63;
            this.check_showall_detail.Text = "Show All";
            this.check_showall_detail.UseVisualStyleBackColor = true;
            this.check_showall_detail.CheckedChanged += new System.EventHandler(this.check_showall_detail_CheckedChanged);
            // 
            // dgv_history_pembayaraan
            // 
            this.dgv_history_pembayaraan.AllowUserToAddRows = false;
            this.dgv_history_pembayaraan.AllowUserToDeleteRows = false;
            this.dgv_history_pembayaraan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_history_pembayaraan.BackgroundColor = System.Drawing.Color.White;
            this.dgv_history_pembayaraan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_history_pembayaraan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_history_pembayaraan.ColumnHeadersHeight = 60;
            this.dgv_history_pembayaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaraan.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_history_pembayaraan.EnableHeadersVisualStyles = false;
            this.dgv_history_pembayaraan.GridColor = System.Drawing.Color.Black;
            this.dgv_history_pembayaraan.Location = new System.Drawing.Point(22, 364);
            this.dgv_history_pembayaraan.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_history_pembayaraan.MultiSelect = false;
            this.dgv_history_pembayaraan.Name = "dgv_history_pembayaraan";
            this.dgv_history_pembayaraan.ReadOnly = true;
            this.dgv_history_pembayaraan.RowHeadersVisible = false;
            this.dgv_history_pembayaraan.RowHeadersWidth = 51;
            this.dgv_history_pembayaraan.RowTemplate.Height = 50;
            this.dgv_history_pembayaraan.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaraan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_history_pembayaraan.Size = new System.Drawing.Size(669, 308);
            this.dgv_history_pembayaraan.TabIndex = 57;
            // 
            // pb_foto_detail
            // 
            this.pb_foto_detail.BackColor = System.Drawing.Color.White;
            this.pb_foto_detail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_foto_detail.Location = new System.Drawing.Point(525, 41);
            this.pb_foto_detail.Name = "pb_foto_detail";
            this.pb_foto_detail.Size = new System.Drawing.Size(120, 120);
            this.pb_foto_detail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_foto_detail.TabIndex = 56;
            this.pb_foto_detail.TabStop = false;
            // 
            // lb_nominal
            // 
            this.lb_nominal.AutoSize = true;
            this.lb_nominal.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal.ForeColor = System.Drawing.Color.Black;
            this.lb_nominal.Location = new System.Drawing.Point(380, 223);
            this.lb_nominal.Name = "lb_nominal";
            this.lb_nominal.Size = new System.Drawing.Size(52, 25);
            this.lb_nominal.TabIndex = 51;
            this.lb_nominal.Text = "Text";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(377, 199);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 17);
            this.label17.TabIndex = 50;
            this.label17.Text = "Fee nominal";
            // 
            // lb_nama
            // 
            this.lb_nama.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama.ForeColor = System.Drawing.Color.Black;
            this.lb_nama.Location = new System.Drawing.Point(41, 149);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(454, 25);
            this.lb_nama.TabIndex = 41;
            this.lb_nama.Text = "Text";
            // 
            // lb_kategori
            // 
            this.lb_kategori.AutoSize = true;
            this.lb_kategori.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori.Location = new System.Drawing.Point(41, 222);
            this.lb_kategori.Name = "lb_kategori";
            this.lb_kategori.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori.TabIndex = 40;
            this.lb_kategori.Text = "Text";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(38, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(38, 199);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 17);
            this.label10.TabIndex = 33;
            this.label10.Text = "Fee category";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.BorderSize = 2;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Green;
            this.button8.Location = new System.Drawing.Point(22, 684);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(126, 37);
            this.button8.TabIndex = 31;
            this.button8.Text = "Back";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(311, 41);
            this.label11.TabIndex = 23;
            this.label11.Text = "Payment History";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.button16);
            this.panel3.Controls.Add(this.panel_not_found);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.check_showall);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.dgv_pembayaran);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(712, 787);
            this.panel3.TabIndex = 46;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Green;
            this.button16.FlatAppearance.BorderSize = 2;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(565, 729);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(126, 37);
            this.button16.TabIndex = 84;
            this.button16.Text = "Check Paid";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // panel_not_found
            // 
            this.panel_not_found.Controls.Add(this.label25);
            this.panel_not_found.Controls.Add(this.pictureBox1);
            this.panel_not_found.Location = new System.Drawing.Point(36, 234);
            this.panel_not_found.Name = "panel_not_found";
            this.panel_not_found.Size = new System.Drawing.Size(640, 318);
            this.panel_not_found.TabIndex = 81;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(272, 285);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 17);
            this.label25.TabIndex = 78;
            this.label25.Text = "Data not found ...";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(186, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(340, 282);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 17);
            this.label9.TabIndex = 76;
            this.label9.Text = "Search by Class";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(202, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 17);
            this.label2.TabIndex = 75;
            this.label2.Text = "Search by name";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.FlatAppearance.BorderSize = 2;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.Green;
            this.button12.Location = new System.Drawing.Point(154, 729);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(126, 37);
            this.button12.TabIndex = 73;
            this.button12.Text = "History";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.tbox_search);
            this.panel12.Location = new System.Drawing.Point(205, 81);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(177, 38);
            this.panel12.TabIndex = 44;
            // 
            // tbox_search
            // 
            this.tbox_search.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_search.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbox_search.Location = new System.Drawing.Point(11, 9);
            this.tbox_search.Name = "tbox_search";
            this.tbox_search.Size = new System.Drawing.Size(155, 19);
            this.tbox_search.TabIndex = 2;
            this.tbox_search.TextChanged += new System.EventHandler(this.tbox_search_TextChanged);
            // 
            // check_showall
            // 
            this.check_showall.AutoSize = true;
            this.check_showall.Location = new System.Drawing.Point(25, 126);
            this.check_showall.Name = "check_showall";
            this.check_showall.Size = new System.Drawing.Size(67, 17);
            this.check_showall.TabIndex = 34;
            this.check_showall.Text = "Show All";
            this.check_showall.UseVisualStyleBackColor = true;
            this.check_showall.CheckedChanged += new System.EventHandler(this.check_showall_CheckedChanged);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(22, 729);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(126, 37);
            this.button4.TabIndex = 30;
            this.button4.Text = "Detail";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dgv_pembayaran
            // 
            this.dgv_pembayaran.AllowUserToAddRows = false;
            this.dgv_pembayaran.AllowUserToDeleteRows = false;
            this.dgv_pembayaran.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_pembayaran.BackgroundColor = System.Drawing.Color.White;
            this.dgv_pembayaran.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_pembayaran.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_pembayaran.ColumnHeadersHeight = 60;
            this.dgv_pembayaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_pembayaran.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_pembayaran.EnableHeadersVisualStyles = false;
            this.dgv_pembayaran.GridColor = System.Drawing.Color.Black;
            this.dgv_pembayaran.Location = new System.Drawing.Point(22, 158);
            this.dgv_pembayaran.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_pembayaran.MultiSelect = false;
            this.dgv_pembayaran.Name = "dgv_pembayaran";
            this.dgv_pembayaran.ReadOnly = true;
            this.dgv_pembayaran.RowHeadersVisible = false;
            this.dgv_pembayaran.RowHeadersWidth = 51;
            this.dgv_pembayaran.RowTemplate.Height = 50;
            this.dgv_pembayaran.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_pembayaran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_pembayaran.Size = new System.Drawing.Size(669, 558);
            this.dgv_pembayaran.TabIndex = 29;
            this.dgv_pembayaran.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_pembayaran_CellContentClick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(565, 101);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 37);
            this.button1.TabIndex = 26;
            this.button1.Text = "Create";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbox_search);
            this.panel1.Location = new System.Drawing.Point(22, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(177, 38);
            this.panel1.TabIndex = 25;
            // 
            // cbox_search
            // 
            this.cbox_search.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_search.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_search.FormattingEnabled = true;
            this.cbox_search.Location = new System.Drawing.Point(2, 4);
            this.cbox_search.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_search.Name = "cbox_search";
            this.cbox_search.Size = new System.Drawing.Size(171, 29);
            this.cbox_search.TabIndex = 43;
            this.cbox_search.SelectedIndexChanged += new System.EventHandler(this.cbox_search_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 41);
            this.label3.TabIndex = 23;
            this.label3.Text = "Payment";
            // 
            // panel_detail2
            // 
            this.panel_detail2.BackColor = System.Drawing.Color.White;
            this.panel_detail2.Controls.Add(this.button10);
            this.panel_detail2.Controls.Add(this.lb_tanggungan_detail2);
            this.panel_detail2.Controls.Add(this.label20);
            this.panel_detail2.Controls.Add(this.lb_status_detail2);
            this.panel_detail2.Controls.Add(this.label14);
            this.panel_detail2.Controls.Add(this.button3);
            this.panel_detail2.Controls.Add(this.dgv_history_pembayaran_detail2);
            this.panel_detail2.Controls.Add(this.lb_kategori_detail2);
            this.panel_detail2.Controls.Add(this.label13);
            this.panel_detail2.Controls.Add(this.lb_nama_detail2);
            this.panel_detail2.Controls.Add(this.lb_bulan_detail2);
            this.panel_detail2.Controls.Add(this.label16);
            this.panel_detail2.Controls.Add(this.label18);
            this.panel_detail2.Controls.Add(this.button9);
            this.panel_detail2.Controls.Add(this.label19);
            this.panel_detail2.Location = new System.Drawing.Point(797, 24);
            this.panel_detail2.Margin = new System.Windows.Forms.Padding(2);
            this.panel_detail2.Name = "panel_detail2";
            this.panel_detail2.Size = new System.Drawing.Size(719, 778);
            this.panel_detail2.TabIndex = 69;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.FlatAppearance.BorderSize = 2;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Green;
            this.button10.Location = new System.Drawing.Point(433, 685);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(126, 37);
            this.button10.TabIndex = 72;
            this.button10.Text = "Export Excel";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // lb_tanggungan_detail2
            // 
            this.lb_tanggungan_detail2.AutoSize = true;
            this.lb_tanggungan_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tanggungan_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_tanggungan_detail2.Location = new System.Drawing.Point(381, 282);
            this.lb_tanggungan_detail2.Name = "lb_tanggungan_detail2";
            this.lb_tanggungan_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_tanggungan_detail2.TabIndex = 71;
            this.lb_tanggungan_detail2.Text = "Text";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(378, 259);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 17);
            this.label20.TabIndex = 70;
            this.label20.Text = "Dependents";
            // 
            // lb_status_detail2
            // 
            this.lb_status_detail2.AutoSize = true;
            this.lb_status_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_status_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_status_detail2.Location = new System.Drawing.Point(42, 282);
            this.lb_status_detail2.Name = "lb_status_detail2";
            this.lb_status_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_status_detail2.TabIndex = 69;
            this.lb_status_detail2.Text = "Text";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(39, 259);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 17);
            this.label14.TabIndex = 68;
            this.label14.Text = "Status";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Green;
            this.button3.Location = new System.Drawing.Point(565, 685);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(126, 37);
            this.button3.TabIndex = 67;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dgv_history_pembayaran_detail2
            // 
            this.dgv_history_pembayaran_detail2.AllowUserToAddRows = false;
            this.dgv_history_pembayaran_detail2.AllowUserToDeleteRows = false;
            this.dgv_history_pembayaran_detail2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_history_pembayaran_detail2.BackgroundColor = System.Drawing.Color.White;
            this.dgv_history_pembayaran_detail2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_history_pembayaran_detail2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_history_pembayaran_detail2.ColumnHeadersHeight = 60;
            this.dgv_history_pembayaran_detail2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaran_detail2.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_history_pembayaran_detail2.EnableHeadersVisualStyles = false;
            this.dgv_history_pembayaran_detail2.GridColor = System.Drawing.Color.Black;
            this.dgv_history_pembayaran_detail2.Location = new System.Drawing.Point(22, 356);
            this.dgv_history_pembayaran_detail2.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_history_pembayaran_detail2.MultiSelect = false;
            this.dgv_history_pembayaran_detail2.Name = "dgv_history_pembayaran_detail2";
            this.dgv_history_pembayaran_detail2.ReadOnly = true;
            this.dgv_history_pembayaran_detail2.RowHeadersVisible = false;
            this.dgv_history_pembayaran_detail2.RowHeadersWidth = 51;
            this.dgv_history_pembayaran_detail2.RowTemplate.Height = 50;
            this.dgv_history_pembayaran_detail2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_history_pembayaran_detail2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_history_pembayaran_detail2.Size = new System.Drawing.Size(669, 316);
            this.dgv_history_pembayaran_detail2.TabIndex = 57;
            this.dgv_history_pembayaran_detail2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_history_pembayaran_detail2_CellContentClick);
            // 
            // lb_kategori_detail2
            // 
            this.lb_kategori_detail2.AutoSize = true;
            this.lb_kategori_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori_detail2.Location = new System.Drawing.Point(381, 199);
            this.lb_kategori_detail2.Name = "lb_kategori_detail2";
            this.lb_kategori_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori_detail2.TabIndex = 51;
            this.lb_kategori_detail2.Text = "Text";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(378, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 17);
            this.label13.TabIndex = 50;
            this.label13.Text = "Category";
            // 
            // lb_nama_detail2
            // 
            this.lb_nama_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_nama_detail2.Location = new System.Drawing.Point(41, 111);
            this.lb_nama_detail2.Name = "lb_nama_detail2";
            this.lb_nama_detail2.Size = new System.Drawing.Size(454, 25);
            this.lb_nama_detail2.TabIndex = 41;
            this.lb_nama_detail2.Text = "Text";
            // 
            // lb_bulan_detail2
            // 
            this.lb_bulan_detail2.AutoSize = true;
            this.lb_bulan_detail2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_bulan_detail2.ForeColor = System.Drawing.Color.Black;
            this.lb_bulan_detail2.Location = new System.Drawing.Point(42, 198);
            this.lb_bulan_detail2.Name = "lb_bulan_detail2";
            this.lb_bulan_detail2.Size = new System.Drawing.Size(52, 25);
            this.lb_bulan_detail2.TabIndex = 40;
            this.lb_bulan_detail2.Text = "Text";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(38, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 17);
            this.label16.TabIndex = 37;
            this.label16.Text = "Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(39, 175);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 17);
            this.label18.TabIndex = 33;
            this.label18.Text = "Month";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.BorderSize = 2;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Green;
            this.button9.Location = new System.Drawing.Point(22, 685);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(126, 37);
            this.button9.TabIndex = 31;
            this.button9.Text = "Back";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(15, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(311, 41);
            this.label19.TabIndex = 23;
            this.label19.Text = "Payment History";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.button14);
            this.panel4.Controls.Add(this.dgv_riwayat_semua);
            this.panel4.Controls.Add(this.button15);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Location = new System.Drawing.Point(727, 38);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(712, 787);
            this.panel4.TabIndex = 74;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Location = new System.Drawing.Point(36, 234);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(640, 318);
            this.panel6.TabIndex = 82;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(272, 285);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(125, 17);
            this.label22.TabIndex = 78;
            this.label22.Text = "Data not found ...";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(186, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(340, 282);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 77;
            this.pictureBox3.TabStop = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Green;
            this.button14.FlatAppearance.BorderSize = 2;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(565, 684);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(126, 37);
            this.button14.TabIndex = 68;
            this.button14.Text = "Export Excel";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // dgv_riwayat_semua
            // 
            this.dgv_riwayat_semua.AllowUserToAddRows = false;
            this.dgv_riwayat_semua.AllowUserToDeleteRows = false;
            this.dgv_riwayat_semua.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_riwayat_semua.BackgroundColor = System.Drawing.Color.White;
            this.dgv_riwayat_semua.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_riwayat_semua.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_riwayat_semua.ColumnHeadersHeight = 60;
            this.dgv_riwayat_semua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_riwayat_semua.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_riwayat_semua.EnableHeadersVisualStyles = false;
            this.dgv_riwayat_semua.GridColor = System.Drawing.Color.Black;
            this.dgv_riwayat_semua.Location = new System.Drawing.Point(22, 88);
            this.dgv_riwayat_semua.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_riwayat_semua.MultiSelect = false;
            this.dgv_riwayat_semua.Name = "dgv_riwayat_semua";
            this.dgv_riwayat_semua.ReadOnly = true;
            this.dgv_riwayat_semua.RowHeadersVisible = false;
            this.dgv_riwayat_semua.RowHeadersWidth = 51;
            this.dgv_riwayat_semua.RowTemplate.Height = 50;
            this.dgv_riwayat_semua.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_riwayat_semua.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_riwayat_semua.Size = new System.Drawing.Size(669, 584);
            this.dgv_riwayat_semua.TabIndex = 57;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.FlatAppearance.BorderSize = 2;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.Green;
            this.button15.Location = new System.Drawing.Point(22, 684);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(126, 37);
            this.button15.TabIndex = 31;
            this.button15.Text = "Back";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(15, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(311, 41);
            this.label26.TabIndex = 23;
            this.label26.Text = "Payment History";
            // 
            // panel_cek
            // 
            this.panel_cek.BackColor = System.Drawing.Color.White;
            this.panel_cek.Controls.Add(this.tableLayoutPanel1);
            this.panel_cek.Controls.Add(this.panel13);
            this.panel_cek.Controls.Add(this.rb_tahun_lainnya_cek);
            this.panel_cek.Controls.Add(this.rb_tahun_ini_cek);
            this.panel_cek.Controls.Add(this.lb_nominal_cek);
            this.panel_cek.Controls.Add(this.label29);
            this.panel_cek.Controls.Add(this.lb_nama_cek);
            this.panel_cek.Controls.Add(this.lb_kategori_cek);
            this.panel_cek.Controls.Add(this.label32);
            this.panel_cek.Controls.Add(this.label33);
            this.panel_cek.Controls.Add(this.button19);
            this.panel_cek.Controls.Add(this.label34);
            this.panel_cek.Location = new System.Drawing.Point(1132, 0);
            this.panel_cek.Margin = new System.Windows.Forms.Padding(2);
            this.panel_cek.Name = "panel_cek";
            this.panel_cek.Size = new System.Drawing.Size(712, 787);
            this.panel_cek.TabIndex = 84;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.panel25, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel22, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel20, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel14, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-36, 271);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(664, 429);
            this.tableLayoutPanel1.TabIndex = 60;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label49);
            this.panel25.Controls.Add(this.lb_december);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(445, 324);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(216, 102);
            this.panel25.TabIndex = 11;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(81, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(76, 17);
            this.label49.TabIndex = 54;
            this.label49.Text = "December";
            // 
            // lb_december
            // 
            this.lb_december.AutoSize = true;
            this.lb_december.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_december.ForeColor = System.Drawing.Color.Green;
            this.lb_december.Location = new System.Drawing.Point(84, 50);
            this.lb_december.Name = "lb_december";
            this.lb_december.Size = new System.Drawing.Size(47, 23);
            this.lb_december.TabIndex = 55;
            this.lb_december.Text = "Text";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label47);
            this.panel24.Controls.Add(this.lb_august);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(224, 324);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(215, 102);
            this.panel24.TabIndex = 10;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(80, 27);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(52, 17);
            this.label47.TabIndex = 54;
            this.label47.Text = "August";
            // 
            // lb_august
            // 
            this.lb_august.AutoSize = true;
            this.lb_august.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_august.ForeColor = System.Drawing.Color.Green;
            this.lb_august.Location = new System.Drawing.Point(83, 50);
            this.lb_august.Name = "lb_august";
            this.lb_august.Size = new System.Drawing.Size(47, 23);
            this.lb_august.TabIndex = 55;
            this.lb_august.Text = "Text";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label51);
            this.panel23.Controls.Add(this.lb_april);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(3, 324);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(215, 102);
            this.panel23.TabIndex = 9;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(80, 27);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(36, 17);
            this.label51.TabIndex = 54;
            this.label51.Text = "April";
            // 
            // lb_april
            // 
            this.lb_april.AutoSize = true;
            this.lb_april.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_april.ForeColor = System.Drawing.Color.Green;
            this.lb_april.Location = new System.Drawing.Point(83, 50);
            this.lb_april.Name = "lb_april";
            this.lb_april.Size = new System.Drawing.Size(47, 23);
            this.lb_april.TabIndex = 55;
            this.lb_april.Text = "Text";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label45);
            this.panel22.Controls.Add(this.lb_november);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(445, 217);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(216, 101);
            this.panel22.TabIndex = 8;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(81, 26);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(77, 17);
            this.label45.TabIndex = 54;
            this.label45.Text = "November";
            // 
            // lb_november
            // 
            this.lb_november.AutoSize = true;
            this.lb_november.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_november.ForeColor = System.Drawing.Color.Green;
            this.lb_november.Location = new System.Drawing.Point(84, 49);
            this.lb_november.Name = "lb_november";
            this.lb_november.Size = new System.Drawing.Size(47, 23);
            this.lb_november.TabIndex = 55;
            this.lb_november.Text = "Text";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.label43);
            this.panel21.Controls.Add(this.lb_july);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(224, 217);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(215, 101);
            this.panel21.TabIndex = 7;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(80, 26);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(31, 17);
            this.label43.TabIndex = 54;
            this.label43.Text = "July";
            // 
            // lb_july
            // 
            this.lb_july.AutoSize = true;
            this.lb_july.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_july.ForeColor = System.Drawing.Color.Green;
            this.lb_july.Location = new System.Drawing.Point(83, 49);
            this.lb_july.Name = "lb_july";
            this.lb_july.Size = new System.Drawing.Size(47, 23);
            this.lb_july.TabIndex = 55;
            this.lb_july.Text = "Text";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label41);
            this.panel20.Controls.Add(this.lb_march);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(3, 217);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(215, 101);
            this.panel20.TabIndex = 6;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(80, 26);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(48, 17);
            this.label41.TabIndex = 54;
            this.label41.Text = "March";
            // 
            // lb_march
            // 
            this.lb_march.AutoSize = true;
            this.lb_march.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_march.ForeColor = System.Drawing.Color.Green;
            this.lb_march.Location = new System.Drawing.Point(83, 49);
            this.lb_march.Name = "lb_march";
            this.lb_march.Size = new System.Drawing.Size(47, 23);
            this.lb_march.TabIndex = 55;
            this.lb_march.Text = "Text";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label35);
            this.panel19.Controls.Add(this.lb_october);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(445, 110);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(216, 101);
            this.panel19.TabIndex = 5;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(81, 26);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 17);
            this.label35.TabIndex = 54;
            this.label35.Text = "October";
            // 
            // lb_october
            // 
            this.lb_october.AutoSize = true;
            this.lb_october.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_october.ForeColor = System.Drawing.Color.Green;
            this.lb_october.Location = new System.Drawing.Point(84, 49);
            this.lb_october.Name = "lb_october";
            this.lb_october.Size = new System.Drawing.Size(47, 23);
            this.lb_october.TabIndex = 55;
            this.lb_october.Text = "Text";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label37);
            this.panel18.Controls.Add(this.lb_june);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(224, 110);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(215, 101);
            this.panel18.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(80, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(38, 17);
            this.label37.TabIndex = 54;
            this.label37.Text = "June";
            // 
            // lb_june
            // 
            this.lb_june.AutoSize = true;
            this.lb_june.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_june.ForeColor = System.Drawing.Color.Green;
            this.lb_june.Location = new System.Drawing.Point(83, 49);
            this.lb_june.Name = "lb_june";
            this.lb_june.Size = new System.Drawing.Size(47, 23);
            this.lb_june.TabIndex = 55;
            this.lb_june.Text = "Text";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label39);
            this.panel17.Controls.Add(this.lb_february);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(3, 110);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(215, 101);
            this.panel17.TabIndex = 3;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(80, 26);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(62, 17);
            this.label39.TabIndex = 54;
            this.label39.Text = "February";
            // 
            // lb_february
            // 
            this.lb_february.AutoSize = true;
            this.lb_february.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_february.ForeColor = System.Drawing.Color.Green;
            this.lb_february.Location = new System.Drawing.Point(83, 49);
            this.lb_february.Name = "lb_february";
            this.lb_february.Size = new System.Drawing.Size(47, 23);
            this.lb_february.TabIndex = 55;
            this.lb_february.Text = "Text";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label30);
            this.panel16.Controls.Add(this.lb_september);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(445, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(216, 101);
            this.panel16.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(81, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(78, 17);
            this.label30.TabIndex = 54;
            this.label30.Text = "September";
            // 
            // lb_september
            // 
            this.lb_september.AutoSize = true;
            this.lb_september.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_september.ForeColor = System.Drawing.Color.Green;
            this.lb_september.Location = new System.Drawing.Point(84, 49);
            this.lb_september.Name = "lb_september";
            this.lb_september.Size = new System.Drawing.Size(47, 23);
            this.lb_september.TabIndex = 55;
            this.lb_september.Text = "Text";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label24);
            this.panel15.Controls.Add(this.lb_may);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(224, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(215, 101);
            this.panel15.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(80, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 17);
            this.label24.TabIndex = 54;
            this.label24.Text = "May";
            // 
            // lb_may
            // 
            this.lb_may.AutoSize = true;
            this.lb_may.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_may.ForeColor = System.Drawing.Color.Green;
            this.lb_may.Location = new System.Drawing.Point(83, 49);
            this.lb_may.Name = "lb_may";
            this.lb_may.Size = new System.Drawing.Size(47, 23);
            this.lb_may.TabIndex = 55;
            this.lb_may.Text = "Text";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label53);
            this.panel14.Controls.Add(this.lb_january);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(215, 101);
            this.panel14.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(80, 26);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(58, 17);
            this.label53.TabIndex = 54;
            this.label53.Text = "January";
            // 
            // lb_january
            // 
            this.lb_january.AutoSize = true;
            this.lb_january.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_january.ForeColor = System.Drawing.Color.Green;
            this.lb_january.Location = new System.Drawing.Point(83, 49);
            this.lb_january.Name = "lb_january";
            this.lb_january.Size = new System.Drawing.Size(47, 23);
            this.lb_january.TabIndex = 55;
            this.lb_january.Text = "Text";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.cbox_spp_cek);
            this.panel13.Location = new System.Drawing.Point(389, 232);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(137, 36);
            this.panel13.TabIndex = 59;
            // 
            // cbox_spp_cek
            // 
            this.cbox_spp_cek.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_spp_cek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbox_spp_cek.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbox_spp_cek.FormattingEnabled = true;
            this.cbox_spp_cek.IntegralHeight = false;
            this.cbox_spp_cek.Location = new System.Drawing.Point(4, 4);
            this.cbox_spp_cek.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_spp_cek.Name = "cbox_spp_cek";
            this.cbox_spp_cek.Size = new System.Drawing.Size(127, 25);
            this.cbox_spp_cek.TabIndex = 43;
            this.cbox_spp_cek.SelectedIndexChanged += new System.EventHandler(this.cbox_spp_cek_SelectedIndexChanged);
            // 
            // rb_tahun_lainnya_cek
            // 
            this.rb_tahun_lainnya_cek.AutoSize = true;
            this.rb_tahun_lainnya_cek.Location = new System.Drawing.Point(244, 243);
            this.rb_tahun_lainnya_cek.Name = "rb_tahun_lainnya_cek";
            this.rb_tahun_lainnya_cek.Size = new System.Drawing.Size(124, 17);
            this.rb_tahun_lainnya_cek.TabIndex = 58;
            this.rb_tahun_lainnya_cek.TabStop = true;
            this.rb_tahun_lainnya_cek.Text = "Another fee category";
            this.rb_tahun_lainnya_cek.UseVisualStyleBackColor = true;
            this.rb_tahun_lainnya_cek.CheckedChanged += new System.EventHandler(this.rb_tahun_lainnya_cek_CheckedChanged);
            // 
            // rb_tahun_ini_cek
            // 
            this.rb_tahun_ini_cek.AutoSize = true;
            this.rb_tahun_ini_cek.Location = new System.Drawing.Point(117, 243);
            this.rb_tahun_ini_cek.Name = "rb_tahun_ini_cek";
            this.rb_tahun_ini_cek.Size = new System.Drawing.Size(121, 17);
            this.rb_tahun_ini_cek.TabIndex = 57;
            this.rb_tahun_ini_cek.TabStop = true;
            this.rb_tahun_ini_cek.Text = "Current fee category";
            this.rb_tahun_ini_cek.UseVisualStyleBackColor = true;
            this.rb_tahun_ini_cek.CheckedChanged += new System.EventHandler(this.rb_tahun_ini_cek_CheckedChanged);
            // 
            // lb_nominal_cek
            // 
            this.lb_nominal_cek.AutoSize = true;
            this.lb_nominal_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_nominal_cek.Location = new System.Drawing.Point(380, 183);
            this.lb_nominal_cek.Name = "lb_nominal_cek";
            this.lb_nominal_cek.Size = new System.Drawing.Size(52, 25);
            this.lb_nominal_cek.TabIndex = 51;
            this.lb_nominal_cek.Text = "Text";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(377, 159);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(87, 17);
            this.label29.TabIndex = 50;
            this.label29.Text = "Fee nominal";
            // 
            // lb_nama_cek
            // 
            this.lb_nama_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_nama_cek.Location = new System.Drawing.Point(41, 109);
            this.lb_nama_cek.Name = "lb_nama_cek";
            this.lb_nama_cek.Size = new System.Drawing.Size(454, 25);
            this.lb_nama_cek.TabIndex = 41;
            this.lb_nama_cek.Text = "Text";
            // 
            // lb_kategori_cek
            // 
            this.lb_kategori_cek.AutoSize = true;
            this.lb_kategori_cek.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_kategori_cek.ForeColor = System.Drawing.Color.Black;
            this.lb_kategori_cek.Location = new System.Drawing.Point(41, 182);
            this.lb_kategori_cek.Name = "lb_kategori_cek";
            this.lb_kategori_cek.Size = new System.Drawing.Size(52, 25);
            this.lb_kategori_cek.TabIndex = 40;
            this.lb_kategori_cek.Text = "Text";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(38, 85);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 17);
            this.label32.TabIndex = 37;
            this.label32.Text = "Name";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(38, 159);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(92, 17);
            this.label33.TabIndex = 33;
            this.label33.Text = "Fee category";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.FlatAppearance.BorderSize = 2;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.Green;
            this.button19.Location = new System.Drawing.Point(16, 729);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(126, 37);
            this.button19.TabIndex = 31;
            this.button19.Text = "Back";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(15, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(311, 41);
            this.label34.TabIndex = 23;
            this.label34.Text = "Payment History";
            // 
            // FormPembayaran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1781, 844);
            this.Controls.Add(this.panel_cek);
            this.Controls.Add(this.panel_detail);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_detail2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPembayaran";
            this.Text = "FormPembayaran";
            this.Load += new System.EventHandler(this.FormPembayaran_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel_not_found_bayar.ResumeLayout(false);
            this.panel_not_found_bayar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_bayar)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_bayar)).EndInit();
            this.panel_detail.ResumeLayout(false);
            this.panel_detail.PerformLayout();
            this.panel_not_found_detail.ResumeLayout(false);
            this.panel_not_found_detail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaraan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto_detail)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel_not_found.ResumeLayout(false);
            this.panel_not_found.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pembayaran)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel_detail2.ResumeLayout(false);
            this.panel_detail2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_history_pembayaran_detail2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_riwayat_semua)).EndInit();
            this.panel_cek.ResumeLayout(false);
            this.panel_cek.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_detail;
        private System.Windows.Forms.PictureBox pb_foto_detail;
        private System.Windows.Forms.Label lb_nominal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_kategori;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox check_showall;
        private System.Windows.Forms.DataGridView dgv_pembayaran;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbox_search;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox tbox_search;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dgv_bayar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox tbox_bayar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cbox_bulan;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox cbox_spp;
        private System.Windows.Forms.RadioButton rb_tahun_lain;
        private System.Windows.Forms.RadioButton rb_tahun_ini;
        private System.Windows.Forms.DataGridView dgv_history_pembayaraan;
        private System.Windows.Forms.CheckBox check_showall_detail;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.ComboBox cbox_spp_detail;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cbox_bulan_detail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox check_spp_detail;
        private System.Windows.Forms.CheckBox check_bulan_detail;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel_detail2;
        private System.Windows.Forms.DataGridView dgv_history_pembayaran_detail2;
        private System.Windows.Forms.Label lb_kategori_detail2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_nama_detail2;
        private System.Windows.Forms.Label lb_bulan_detail2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lb_tanggungan_detail2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lb_status_detail2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.PictureBox pb_foto_bayar;
        private System.Windows.Forms.Label lb_nominal_bayar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_nama_bayar;
        private System.Windows.Forms.Label lb_kategori_bayar;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.DataGridView dgv_riwayat_semua;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_not_found;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel_not_found_detail;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel_not_found_bayar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel_cek;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label lb_december;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lb_august;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label lb_april;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lb_november;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lb_july;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lb_march;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lb_october;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lb_june;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lb_february;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lb_september;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lb_may;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label lb_january;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.ComboBox cbox_spp_cek;
        private System.Windows.Forms.RadioButton rb_tahun_lainnya_cek;
        private System.Windows.Forms.RadioButton rb_tahun_ini_cek;
        private System.Windows.Forms.Label lb_nominal_cek;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lb_nama_cek;
        private System.Windows.Forms.Label lb_kategori_cek;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.DataGridViewButtonColumn Remove;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_spp;
        private System.Windows.Forms.DataGridViewTextBoxColumn bulan_bayar;
        private System.Windows.Forms.DataGridViewTextBoxColumn tahun_bayar;
        private System.Windows.Forms.DataGridViewTextBoxColumn keterangan_spp;
        private System.Windows.Forms.DataGridViewTextBoxColumn nominal_bayar;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlah_bayar;
    }
}